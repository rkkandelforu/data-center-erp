<?php
ob_start();
include("connect.php");
@session_start();

if (isset($_SESSION['email'])) {
    $email = $_SESSION["email"];
    include("userheader.php");
} else {
    header("userloginpage.php");
}


$arr = array();
$arr = $_SESSION['billdata'];
$sql2 = "select * from pricing inner join package on package.packageid=pricing.packageid where pid='" . $arr["pricingid"] . "'";
$result = mysqli_query($conn, $sql2);
$row = mysqli_fetch_array($result);
date_default_timezone_set("Asia/Kolkata");
$currentDateTime = date('Y-m-d H:i:s');
$sql = "INSERT INTO `bill`(`billid`, `total`, `datetime`, `custid`, `pricingid`, `dateofexpiry`) VALUES (null ,'" . $arr["total"] . "','" . $currentDateTime . "','" . $arr["custid"] . "','" . $arr["pricingid"] . "','" . $arr["doe"] . "')";
if (mysqli_query($conn, $sql)) {
    $id=mysqli_insert_id($conn);
    error_reporting(E_STRICT);

    date_default_timezone_set('Asia/Kolkata');

    require_once('PHPMailer/class.phpmailer.php');
//include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded

    $mail = new PHPMailer();

    /*$body             = file_get_contents('contents.html');
    $body             = preg_replace('/[\]/','',$body);*/

    $mail->IsSMTP(); // telling the class to use SMTP
    $mail->Host = "mail.yourdomain.com"; // SMTP server
    $mail->SMTPDebug = 1;                     // enables SMTP debug information (for testing)
    // 1 = errors and messages
    // 2 = messages only
    $mail->SMTPAuth = true;                  // enable SMTP authentication
    $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
    $mail->Host = "smtp.gmail.com";      // sets GMAIL as the SMTP server
    $mail->Port = 465;                   // set the SMTP port for the GMAIL server
    $mail->Username = "vmmstudents2020@gmail.com";  // GMAIL username
    $mail->Password = "Temp@1234";            // GMAIL password

    $mail->SetFrom('vmmstudents2020@gmail.com', 'Hosting City');

    $mail->AddReplyTo("vmmstudents2020@gmail.com", "Hosting City");

    $mail->Subject = "Purchase Of Product";

    $mail->AltBody = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
    $body = "Thanks for shopping with us:-<br>You have successfully purchase a package from us which contains following terms : <br>Package Name : " . $row["packagename"] . "<br>Amount : " . $arr["total"] . " <br>Duration : " . $row["duration"] . " months <br>Expiry Date : " . $arr["doe"] . "";
    $mail->MsgHTML($body);

    $address = $email;
    $mail->AddAddress($address, "John Doe");

    /*$mail->AddAttachment("images/phpmailer.gif");      // attachment
    $mail->AddAttachment("images/phpmailer_mini.gif"); */// attachment

    if (!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    }
    $_SESSION['billdata'] = null;
    unset($_SESSION['billdata']);
    header("Location:thankyou.php?q=$id");

} else {
    header("Location:index.php?er=0");
}