<?php
session_start();
include_once "connect.php";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php
    include "headerfiles.php";
    ?>
    <title>Document</title>
</head>
<body>
<?php
include "userheader.php";
?>
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <form action="userupdatepassword.php" id="form1" method="post" enctype="multipart/form-data">
                <div class="row ml-3 justify-content-center">
                    <div class="input-containder">
                        <h1 class="text-danger input-field">Change Password</h1>
                    </div>
                </div>


                <input type="password" name="oldpassword" id="oldpassword"
                       placeholder="enter old password"
                       data-rule-required="true" data-msg-required="Please enter old password"
                       class="input-field">

                <input type="password" name="newpassword" id="newpassword"
                       placeholder="enter new password"
                       data-rule-required="true" data-msg-required="Please enter new password"
                       class="input-field">

                <input type="password" name="newconpassword" id="newconpassword"
                       placeholder="enter confirm password"
                       data-rule-required="true" data-msg-required="Please enter confirm new password"
                       data-rule-equalto="#newpassword"
                       data-msg-equalto="New Password and confirm new password must be same"
                       class="input-field">


                <div class="row">
                    <div class="input-container justify-content-center">
                        <input type="submit" value="submit"
                               class="btn btn-success w-25">
                    </div>
                    <?php
                    if (isset($_REQUEST['er'])) {
                        $val = $_REQUEST['er'];
                        if ($val == 2) {
                            echo '<div class="alert alert-danger">
                        Password changed successfully
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                        }
                        if ($val == 3) {
                            echo '<div class="alert alert-danger">
                        Old Password does not match
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                        }

                    }

                    ?>
            </form>


        </div>
    </div>
</div>
<?php
include_once 'footer.php';
?>
</body>
</html>
<?php
