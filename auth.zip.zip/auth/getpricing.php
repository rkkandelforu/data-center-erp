<?php
include_once 'connect.php';
if (isset($_GET['q'])) {
    $pack = $_GET['q'];
    $qury = "select * from pricing inner join package on pricing.packageid=package.packageid where pricing.packageid='$pack'";
} else {
    $qury = "select * from pricing inner join package on pricing.packageid=package.packageid";
}
$k = 0;
$result = mysqli_query($conn, $qury);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        $k++;
        ?>
        <tr>
            <td><?php echo $k; ?></td>
            <td><?php echo $row['category']; ?></td>
            <td><?php echo $row['packagename']; ?></td>
            <td><?php echo $row['amount']; ?></td>
            <td><?php echo $row['duration']; ?> months</td>
            <td><?php echo $row['offer']; ?> %</td>
            <td><a href="editpricing.php?q=<?php echo $row['pid']; ?>"><i class="fa fa-edit"></i></a></td>
            <td><a onclick="return confirm('Are you Sure you want to Delete?')"
                   href="deletepricing.php?q=<?php echo $row['pid']; ?>"><i class="fa fa-trash"></i></a>
            </td>
        </tr>
        <?php
    }
} else {
    echo "No Data Found";
}
?>