<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include_once 'headerfiles.php';
    ?>
</head>
<body>
<?php
include_once 'adminheader.php';
?>
<div class="registration">
    <div class="about-heading">
        <h2>All Products @ <span><h2>Two Minds <span> Technology</span></h2></span></h2>
    </div>
    <div class="container">
        <div class="table-responsive">
            <table class="table table-bordered table-condensed bg-warning">
                <thead>
                <tr>
                    <th>Sr no.</th>
                    <th>Purchased Date</th>
                    <th>Thumb Nail</th>
                    <th>Package Name</th>
                    <th>Package Category</th>
                    <th>Actual Amount</th>
                    <th>Offer</th>
                    <th>Paid Amount</th>
                    <th>Duration</th>
                    <th>Date of Expiry</th>
                    <th>Customer Id</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $k = 0;
                $sql = "select *,users.custid as cust from bill inner join pricing on bill.pricingid=pricing.pid inner join package on package.packageid=pricing.packageid inner join users on users.id=bill.custid";
                //                echo $sql;
                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_array($result)) {
                        $k++;
                        ?>
                        <tr>
                            <td><?php echo $k; ?></td>
                            <td><?php echo $row["datetime"]; ?></td>
                            <td><img style="height: 50px;width: 70px" src="<?php echo $row["photo"]; ?>" alt=""></td>
                            <td><?php echo $row["packagename"]; ?></td>
                            <td><?php echo $row["category"]; ?></td>
                            <td>&#8377;&nbsp;<?php echo $row["amount"]; ?></td>
                            <td><?php echo $row["offer"]; ?>%</td>
                            <td>&#8377;&nbsp;<?php echo $row["total"]; ?></td>
                            <td><?php echo $row["duration"]; ?> months</td>
                            <td><?php echo $row["dateofexpiry"]; ?></td>
                            <td><?php echo $row["cust"]; ?></td>
                        </tr>
                        <?php
                    }
                } else {
                    echo "No Products Found";
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php
include_once 'footer.php';
?>
</body>
</html>
<?php
