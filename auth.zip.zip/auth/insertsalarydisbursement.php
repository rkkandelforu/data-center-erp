<?php
if (isset($_POST['adminid'])) {
    include_once 'connect.php';

    $adminid = $_POST['adminid'];
    $salary = $_POST['salary'];
    $perk = $_POST['perk'];
    $year = $_POST['year'];
    $month = $_POST['month'];
    date_default_timezone_set("Asia/Kolkata");
    $currentDateTime = date('Y-m-d');
    $sql = "select * from salary_disburse where adminid='$adminid' and month='$month' and year ='$year'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        header("Location:addsalarydisbursement.php?er=0");
    } else {
        $sql2 = "INSERT INTO `salary_disburse`(`sdid`, `dateofdisbursement`, `salary`, `perks`, `month`, `year`, `adminid`) VALUES (null,'$currentDateTime','$salary','$perk','$month','$year','$adminid')";
        if (mysqli_query($conn, $sql2)) {
            header("Location:addsalarydisbursement.php?er=1");
        } else {
            header("Location:addsalarydisbursement.php?er=2");
        }
    }


} else {
    header("Location:addsalarydisbursement.php");
}