<?php
//ob_start();
include_once "connect.php";
@session_start();
if (isset($_SESSION["email"])) {
    $email = $_SESSION["email"];
    $user = "select * from users where email='$email'";
    $user_result = mysqli_query($conn, $user);
    $user_row = mysqli_fetch_array($user_result);
} else {
    header("location:userloginpage.php");
}
?>
<div class="header-top">
    <div class="container">
        <div class="w3layouts-address">
            <ul>
                <li><i class="fa fa-phone" aria-hidden="true"></i>+91 844 740 3460</li>
                <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="mailto:info@example.com">sumit.katharia@twominds.co.in</a></li>
            </ul>
        </div>
        <div class="agileinfo-social-grids">
            <ul>
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-rss"></i></a></li>
                <li><a href="#"><i class="fa fa-vk"></i></a></li>
            </ul>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<!-- //header-top -->
<!-- header -->
<div class="header">
    <div class="container-fluid">
        <nav class="navbar navbar-default">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="w3layouts-logo">
                    <h1><a href="index.php"> <span>Two Minds Technology</span></a></h1>
                </div>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
                <nav>
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="userhome.php">Home</a></li>
                        <li class=""><a href="shop.php?q=Hosting">Hosting</a></li>
                        <li class=""><a href="shop.php?q=Domains">Domains</a></li>
                        <li class=""><a href="shop.php?q=VPN">VPN</a></li>
                        <li class=""><a href="shop.php?q=Storage">Storage</a></li>
                        <li><a href="discussion-forum.php" class="hvr-sweep-to-bottom">Discussions</a></li>
                        <li><a class="hvr-sweep-to-bottom" href="addproblem.php">Customer Support</a></li>
                        <li><a href="myorder.php" class="hvr-sweep-to-bottom">My Products</a></li>
                        <li><a href="myproblem.php" class="hvr-sweep-to-bottom">My Problems</a></li>
                        <li class="dropdown">
                            <a class="dropdown-toggle hvr-sweep-to-bottom" data-toggle="dropdown">
                                <?php if (isset($_SESSION['email'])) {
                                    echo "WELCOME , " . $_SESSION['email'];
                                } ?>
                            </a>
                            <ul class="nav navbar-nav dropdown-menu">
                                <li><a class="hvr-sweep-to-bottom" href="userchangepassword.php">Change Password</a></li>
                                <?php if (isset($_SESSION['email'])) { ?>
                                    <li><a class="hvr-sweep-to-bottom" href="userlogout.php">Logout</a></li>
                                <?php } ?>
                            </ul>
                        </li>
<!--                        <li><a href="userchangepassword.php" class="hvr-sweep-to-bottom">Change Password</a></li>-->
<!---->
<!--                        --><?php // if(isset($_SESSION['email'])) {?>
<!--                            <li><a class="hvr-sweep-to-bottom" href="userlogout.php">Logout</a></li>-->
<!--                        --><?php //} ?>
                    </ul>
                </nav>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
    </div>
</div>

