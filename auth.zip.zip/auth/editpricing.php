<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include 'headerfiles.php';
    ?>
</head>
<body>
<?php
include 'adminheader.php';
include_once 'connect.php';
$id = $_GET['q'];
$query = "select * from pricing where pid='$id'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
//print_r($row);

?>

<div class="about-heading">
    <h2>Two Minds <span> Technology</span></h2>
</div>
<!-- //about-heading -->
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <h3>Edit Pricing Form</h3>
            <div class="login-form">
                <form action="updatepricing.php" id="form1" method="post">
                    <div class="row form-group justify-content-center">
                        <label for="category" class="font-weight-bolder"><u>Package</u></label>
                        <select name="package" id="package" data-rule-required="true"
                                data-msg-required="Package selection is mandatory" class="form-control">
                            <option value="">Select Package</option>
                            <?php
                            $sqls = "select * from package";
                            $results = mysqli_query($conn, $sqls);
                            while ($pack = mysqli_fetch_array($results)) {
                                ?>
                                <option value="<?php echo $pack["packageid"]; ?>"
                                        <?php if (($row['packageid']) == $pack['packageid'])   { ?>selected<?php } ?>><?php echo $pack["packagename"]; ?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="row form-group justify-content-center">
                        <label for="amount" class="font-weight-bolder"><u>Package Amount</u></label>
                        <input type="text" name="amount" id="amount" data-rule-required="true" data-rule-number="true"
                               data-msg-required="Package amount is mandatory" value="<?php echo $row["amount"];?>" placeholder="enter package amount"
                               class="input-field">
                    </div>
                    <div class="row form-group justify-content-center">
                        <label for="duration" class="font-weight-bolder"><u>Package Duration</u></label>
                        <input type="text" name="duration" id="duration" data-rule-required="true"
                               data-msg-required="Package duration is mandatory" value="<?php echo $row["duration"];?>" data-rule-number="true" placeholder="enter package duration"
                               class="input-field">
                    </div>
                    <div class="row form-group justify-content-center">
                        <label for="offer" class="font-weight-bolder"><u>Package Offer (in %)</u></label>
                        <input type="text" name="offer" id="offer" data-rule-required="true" data-rule-number="true"
                               data-msg-required="Package offer is mandatory" value="<?php echo $row["offer"];?>" placeholder="enter package offer"
                               class="input-field">
                    </div>
                    <div class="tp">
                        <input type="hidden" value="<?php echo $row["pid"];?>" readonly name="id" id="id">
                        <input type="submit" name="submit" value="Save Changes">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
include_once 'footer.php';
?>
</body>
</html>
