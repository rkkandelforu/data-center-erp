<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include_once 'headerfiles.php';
    ?>

</head>
<body>
<?php
include_once 'adminheader.php';
?>
<br>
<br>
<br>

<div class="registration">
    <div class="container">
        <div class="row justify-content-around">
            <h2>Welcome to Admin Home</h2>
        </div>
    </div>
</div>
<br>

<?php
include 'footer.php';
?>
</body>
</html>
