<?php
@session_start();
include "connect.php";
?>
<!DOCTYPE html>
<html lang="en">
<!-- Head -->
<head>
    <?php
    include "headerfiles.php";
    ?>
</head>
<body>
<!-- banner -->
<?php
if (!isset($_SESSION["email"])) {
    include "navbar.php";
    $email = "";
} else {
    include "userheader.php";
}

?>
<!-- //banner -->
<div class="container">
    <div class="w3ls-heading">
        <h3>Thanks</h3>
    </div>

</div>
<div class="bhoechie-tab-content">
    <div class="container">
        <div class="jumbotron">
            Thank you for Booking with us. Your Booking ID is <?php echo $_REQUEST['q']; ?>
        </div>
    </div>

</div>
<?php
include "footer.php"
?>
</body>
<!-- //Body -->
</html>