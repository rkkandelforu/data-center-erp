<?php
include_once "connect.php";
if(isset($_POST['submit'])){

    $cid = $_REQUEST['cid'];
    $email = $_REQUEST['email'];
    $pass = $_REQUEST['password'];
    $cpass = $_REQUEST['conpassword'];
    $gender = $_REQUEST['gender'];
    $mob = $_REQUEST['mobile'];

    if($pass == $cpass){

        $check = "SELECT email FROM `users` WHERE email = '$email'";
        $res2 = mysqli_query($conn, $check);
        $count = mysqli_num_rows($res2);

        if($count > 0){
            $alert = "000";
            header('Location:registration.php?status='.$alert);
        }else {
            $sql = "INSERT INTO `users` VALUES(NULL,'$cid','$email','$pass','$mob','$gender')";

            $res = mysqli_query($conn, $sql);

            if($res){
                $alert = "11";
                header('Location:registration.php?status='.$alert);
            }else {
                $alert = "00";
                header('Location:registration.php?status='.$alert);
            }
        }
    }else {
        $alert = "0";
        header('Location:registration.php?status='.$alert);
    }



}