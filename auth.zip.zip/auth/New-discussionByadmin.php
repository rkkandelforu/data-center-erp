<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include 'headerfiles.php';
    ?>
</head>
<body>
<?php
include_once 'adminheader.php';
?>

<div class="about-heading">
    <h2>Add Discussion <span>    <h2>Two Minds <span> Technology</span></h2>
</span></h2>
</div>
<!-- //about-heading -->
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <h3>Discussion</h3>
            <div class="login-form">
                <form action="insertdiscussion.php" id="form1" method="post">

                    <input type="text" name="title" id="title"
                           placeholder="enter title"
                           data-rule-required="true" data-msg-required="Please enter Title">
                    <textarea name="desc" id="desc"
                              placeholder="enter description"
                              data-rule-required="true" data-msg-required="Please enter description"></textarea>

                    <div class="tp">
                        <input type="submit" name="submit" value="Create Discussion">
                    </div>
                </form>
            </div>

            <?php
            if (isset($_REQUEST['er'])) {
                $val = $_REQUEST['er'];
                if ($val == 1) {
                    echo '<div class="alert alert-success">
             Discussion added Successfully   
             <span class="close" data-dismiss="alert">&times;</span>
             </div>';
                } elseif ($val == 2) {
                    echo '<div class="alert alert-danger">
            Discussion insert failed
            <span class="close" data-dismiss="alert">&times;</span>
            </div>';
                }

            }
            ?>
        </div>
    </div>
</div>

<?php
include_once 'footer.php';
?>
</body>
</html>
