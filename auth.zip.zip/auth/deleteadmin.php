<?php
include 'adminheader.php';
include_once 'connect.php';

$username = $_REQUEST["username"];
$qury = "delete from admin where username ='$username'";
if (mysqli_query($conn,$qury))
{
    header("location:show_admin.php?er=0");
}
else{
    header("location:show_admin.php?er=1");
}
