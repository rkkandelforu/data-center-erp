<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php
    include "headerfiles.php";
    ?>
    <title>Document</title>
</head>
<body>
<?php
include "adminheader.php";
?>

<div class="about-heading">
    <h2>Two Minds <span> Technology</span></h2>
</div>
<!-- //about-heading -->
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <h3>Change password</h3>
            <div class="login-form">
                <form action="updatepassword.php" id="form1" method="post">
                    <input type="password" name="oldpassword" id="oldpassword"
                           placeholder="enter old password"
                           data-rule-required="true" data-msg-required="Please enter old password">
                    <input type="password" name="newpassword" id="newpassword"
                           placeholder="enter new password"
                           data-rule-required="true" data-msg-required="Please enter new password">
                    <input type="password" name="newconpassword" id="newconpassword"
                           placeholder="enter confirm password"
                           data-rule-required="true" data-msg-required="Please enter confirm new password"
                           data-rule-equalto="#newpassword"
                           data-msg-equalto="New Password and confirm new password must be same">
                    <div class="tp">
                        <input type="submit" name="submit" value="CHANGE PASSWORD">
                    </div>
                </form>
            </div>

            <?php
            if (isset($_REQUEST['er'])) {
                $val = $_REQUEST['er'];
                if ($val == 1) {
                    echo '<div class="alert alert-danger">
                        Password changed successfully
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                }
                if ($val == 2) {
                    echo '<div class="alert alert-danger">
                        Failed to change password.
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                }
                if ($val == 3) {
                    echo '<div class="alert alert-danger">
                        Old Password does not match
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                }
            }
            ?>
        </div>
    </div>
</div>
<?php
include_once 'footer.php';
?>
</body>
</html>
