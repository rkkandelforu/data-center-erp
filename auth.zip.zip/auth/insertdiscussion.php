<?php
include_once 'connect.php';
include_once "adminheader.php";
$title = $_POST["title"];
$desc = $_POST["desc"];


$qury = "INSERT INTO `discussion_forum`(`id`, `title`, `detail`, `postedby`) VALUES (null,'$title','$desc','$username')";
if (mysqli_query($conn, $qury)) {
    echo "Insert Success";
    header("Location:New-discussionByadmin.php?er=1");
} else {
    echo "Insert Failed";
    header("Location:New-discussionByadmin.php?er=2");
}

