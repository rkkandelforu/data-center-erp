<?php
include_once 'connect.php';
if (isset($_GET['q'])) {
    $pack = $_GET['q'];
    $qury = "select * from admin where username='$pack'";
    $result1 = mysqli_query($conn, $qury);
    $row1 = mysqli_fetch_array($result1);
    $salary = $row1[8];
}
?>
<label for="salary">Salary</label>
<input type="text" name="salary" id="salary" value="<?php echo $salary; ?>" readonly>
