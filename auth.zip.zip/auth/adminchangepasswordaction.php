<?php
include_once "connect.php";
session_start();
if (isset($_POST['submit'])) {
    $email = $_REQUEST['email'];
    $pass = encryptpassword($_REQUEST['password']);
    $newpass = encryptpassword($_REQUEST['newpassword']);
    $newconpassword = encryptpassword($_REQUEST['newconpassword']);

    if($newpass ==$newconpassword) {
        $sql = "SELECT * FROM `users` WHERE email = '$email' AND password= '$pass'";
        $res = mysqli_query($conn, $sql);
        $count = mysqli_num_rows($res);
        if ($count > 0) {
            $sqlq = "update `users` Set password= '$newpass' WHERE email = '$email' ";
            $resq = mysqli_query($conn, $sqlq);

            $alert = "success";
            header('Location: adminchangepassword.php?status=' . $alert);
        } else {
            $alert = "wrong";
            header('Location: adminchangepassword.php?status=' . $alert);
        }
    }else{
        $alert = "pass";
        header('Location: adminchangepassword.php?status=' . $alert);
    }
}

function encryptpassword($input)
{
    $salt = '$2a$07$usesomadasdsadsadsadasdasdasdsadesillystringfors';
    return crypt($input, $salt);

}


?>