<?php
include_once 'connect.php';
include 'adminheader.php';

if (isset($_POST['id'])) {
    $id = $_POST["id"];
    $name = $_POST["packagename"];
    $description = $_POST["description"];
    $category = $_POST["category"];
    $photo = $_FILES["symbol"]["tmp_name"];

    $flag = 0;
    $path = '';
    $error = "";
    if ($photo != "") {
        $filename = $_FILES["symbol"]["name"];
        $ext = pathinfo(strtolower($filename), PATHINFO_EXTENSION);
        if ($ext != "jpg" and $ext != "png") {
            $error = "Please select jpg or png image only";
            $flag = 1;
//        header("location:showreligion.php?er=4");
        } elseif (round($_FILES["symbol"]["size"] / 1024) > 200) {
            $error = "Image size must be less than 100 kb";
            $flag = 2;
//        header("location:showreligion.php?er=3");
        } else {
            $path = "photos/$filename";
            move_uploaded_file($photo, $path);
        }
    }
    if ($error == "") {
        $qury = "";
        if ($path == '') {
            $qury = "UPDATE `package` SET `category`='$category', `description`='$description', `packagename`='$name' WHERE packageid='$id'";

        } else {
            $qury = "UPDATE `package` SET `category`='$category',`description`='$description',`photo`='$path',`packagename`='$name' WHERE packageid='$id'";
        }
//        echo $qury;
        if (mysqli_query($conn, $qury)) {
            header("location:showpackage.php?er=0");
        } else {
            header("location:showpackage.php?er=1");
        }
    } else {
//    echo $error;
        if ($flag == 1) {
            header("location:showpackage.php?er=2");
        } elseif ($flag == 2) {
            header("location:showpackage.php?er=3");
        }
    }
} else {
    header("Location:showpackage.php");
}
