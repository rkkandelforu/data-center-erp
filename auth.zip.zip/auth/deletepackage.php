<?php
include 'adminheader.php';
include_once 'connect.php';

$id = $_REQUEST["q"];
$qury = "delete from package where packageid ='$id'";
if (mysqli_query($conn, $qury)) {
    header("location:showpackage.php?er=5");
} else {
    header("location:showpackage.php?er=6");
}
