<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Two Minds Technology</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="Hosting City Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"/>
    <?php include_once "headerfiles.php"; ?>
    <style>
        .panel-heading {
            padding: 10px 15px;
        }

        .panel-body {
            padding: 0px 10px !important;
        }

        .btn {
            padding: 0px !important;
        }
    </style>
</head>
<body>
<?php
if (!isset($_SESSION["email"])) {
    include_once "navbar.php";
    ?>
    <?php
} else {
    include_once "connect.php";
    include_once "userheader.php";
    ?>
<?php } ?>
<!-- banner -->
<div class="container">
    <h2 class="text-center">Questions</h2>
    <?php
    include_once "connect.php";
    $sql = "select * from discussion_forum";
    $sqldata = mysqli_query($conn, $sql);
    $srno = 1;
    while ($rowforum = mysqli_fetch_array($sqldata)) {
        ?>
        <div class="panel panel-info">
            <div class="panel panel-heading"><h4><?php echo $srno; ?> ) <?php echo $rowforum[1]; ?> ?</h4></div>
            <div class="panel panel-body">
                <p><?php echo $rowforum[2]; ?></p>

                <span class="badge badge-primary"
                      style="float: right;margin-right: 20px;"><?php echo $rowforum[4]; ?></span>
            </div>
            <div class="panel panel-footer ">
                <div class="row">
                    <div class="col-sm-9">
                        <div id="panel<?php echo $rowforum[0]; ?>" class="collapse form-group">
                            <form action="replyaction.php" method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-sm-10">
                                        <div class="form-group">
                                            <input type="hidden" name="discussionid" id="discussionid"
                                                   value="<?php echo $rowforum[0]; ?>">
                                            <textarea name="replytext" id="replytext" class="form-control"
                                                      placeholder="enter your reply here..."></textarea>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <div class="image-upload">
                                                <label for="rphoto">
                                                    <label>Upload Photo</label>
                                                    <img src="images/photo.png" height="40"/>
                                                </label>

                                                <input type="file" name="rphoto" id="rphoto" style="display: none;"/>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="image-upload">
                                                <label for="rvideo">
                                                    <label>Upload Video</label>
                                                    <img src="images/video.png" height="40"/>
                                                </label>

                                                <input id="rvideo" name="rvideo" type="file" style="display: none;"/>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <input type="submit" value="Submit" class="btn btn-success">
                                        </div>

                                    </div>

                                </div>


                            </form>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <?php
                        if (isset($_SESSION["email"])) {
                            ?>
                            <button type="button" data-toggle="collapse" data-target="#panel<?php echo $rowforum[0]; ?>"
                                    class="btn btn-sm btn-info" style="float: right;margin-right: 20px;"><i
                                        class="fa fa-reply"></i> reply
                            </button>
                            <?php
                        } else {
                            echo "<a href='userloginpage.php'>login to reply</a>";
                        }
                        ?>
                    </div>

                </div>


            </div>

            <div class="panel panel-success">
                <div class="panel panel-heading">
                <h5>User's Replies</h5>
                </div>
                <?php
                $sqlreply = "select * from discussion_forum_reply where discussionid=" . $rowforum[0];
                $sqldatareply = mysqli_query($conn, $sqlreply);
                while ($rowreply = mysqli_fetch_array($sqldatareply)) {
                    ?>
                    <div class="container">

                        <div class="row">
                            <div class="col-sm-6"><p><?php echo $rowreply['replytext'] ?></p></div>
                            <div class="col-sm-3"><img height="80" src="<?php echo $rowreply['replyimage'] ?>" alt="">
                            </div>
                            <div class="col-sm-3">
                                <video src="<?php echo $rowreply['replyvideourl'] ?>" width="100"></video>
                            </div>
                        </div>

                    </div>
                    <?php
                }
                ?>

            </div>


        </div>
        <?php
    }
    ?>
</div>


<?php include_once "footer.php"; ?>
</body>
</html>