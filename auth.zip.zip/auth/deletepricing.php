<?php
include 'adminheader.php';
include_once 'connect.php';

$id = $_REQUEST["q"];
$qury = "delete from pricing where pid ='$id'";
if (mysqli_query($conn,$qury))
{
    header("location:showpricing.php?er=0");
}
else{
    header("location:showpricing.php?er=1");
}
