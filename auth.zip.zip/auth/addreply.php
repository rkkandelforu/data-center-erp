<?php
include_once 'connect.php';

$description = $_POST["description"];
$csid = $_POST["csid"];
date_default_timezone_set("Asia/Kolkata");
$currentDateTime = date('Y-m-d H:i:s');

$qury = "INSERT INTO `reply`(`replyid`, `replydt`, `description`, `csid`,`replyby`) VALUES (null ,'$currentDateTime','$description','$csid','CSE')";
if (mysqli_query($conn, $qury)) {
    echo "Insert Success";
    header("Location:showproblem.php?er=0");
} else {
    echo "Insert Failed";
    header("Location:showproblem.php?er=1");
}