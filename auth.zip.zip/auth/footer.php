<!-- footer -->
<div class="footer">
    <div class="container">
<!--        <div class="agile-footer-grids">-->
            <div class="col-md-6 agile-footer-grid">
                <h4><span>Posts</span></h4>
                <ul class="w3agile_footer_grid_list">
                    <li><a href="#">sumit.katharia@twominds.co.in</a>
                </ul>
            </div>
            <div class="col-md-6 agile-footer-grid">
                <h4>Popular <span>Posts</span></h4>
                <div class="popular-grids">
                    <div class="popular-grid">
                        <a href="#"><img src="images/6.jpg" alt=""></a>
                    </div>
                    <div class="popular-grid">
                        <a href="#"><img src="images/8.jpg" alt=""></a>
                    </div>
                    <div class="popular-grid">
                        <a href="#"><img src="images/9.jpg" alt=""></a>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="popular-grids agileits-w3layouts-popular">
                    <div class="popular-grid">
                        <a href="#"><img src="images/10.jpg" alt=""></a>
                    </div>
                    <div class="popular-grid">
                        <a href="#"><img src="images/4.jpg" alt=""></a>
                    </div>
                    <div class="popular-grid">
                        <a href="#"><img src="images/7.jpg" alt=""></a>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
            <div class="clearfix"> </div>
<!--        </div>-->
    </div>
    <div class="copyright">
        <p>© 2020 Two Minds Technology. All rights reserved | Design by <a href="">Student Name</a></p>
    </div>
</div>
<!-- //footer -->
<script src="js/jarallax.js"></script>
<script type="text/javascript">
    /* init Jarallax */
    $('.jarallax').jarallax({
        speed: 0.5,
        imgWidth: 1366,
        imgHeight: 768
    })
</script>
<script src="js/responsiveslides.min.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<!-- here stars scrolling icon -->
<script type="text/javascript">
    $(document).ready(function() {
        /*
            var defaults = {
            containerID: 'toTop', // fading element id
            containerHoverID: 'toTopHover', // fading element hover id
            scrollSpeed: 1200,
            easingType: 'linear'
            };
        */

        $().UItoTop({ easingType: 'easeOutQuart' });

    });
</script>
<!-- //here ends scrolling icon -->
<!-- pricing -->
<script src="js/jquery.flipster.js"></script>
<script>
    <!--

    $(function(){ $(".flipster").flipster({ style: 'carousel', start: 0 }); });

    -->
</script>
<!-- //pricing -->
<!-- slider -->
<script type="text/javascript" src="js/jquery.immersive-slider.js"></script>
<!-- //slider -->