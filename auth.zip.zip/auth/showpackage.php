<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Two Minds Technology</title>
    <?php
    ob_start();
    include_once 'headerfiles.php';
    ?>
</head>
<body>
<?php
include_once 'adminheader.php';
?>
<div class="main-sec"></div>

<div class="container">
    <table class="table table-striped table-bordered">
        <thead>
        <tr>
            <th>Sr no.</th>
            <th>Photo</th>
            <th>Package Name</th>
            <th>Description</th>
            <th>Category</th>
            <th>Delete</th>
            <th>Edit</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $k = 0;
        $qury = "select * from package";
        $result = mysqli_query($conn, $qury);
        if (mysqli_num_rows($result) > 0) {
            while ($religion = mysqli_fetch_array($result)) {
                $k++;
                ?>
                <tr>
                    <td><?php echo $k ?></td>
                    <td><img style="height: 150px;width: 250px" src="<?php echo $religion["photo"]; ?>" alt=""></td>
                    <td><?php echo $religion[1]; ?></td>
                    <td><?php echo $religion[2]; ?></td>
                    <td><?php echo $religion[4]; ?></td>
                    <td><a onclick="return confirm('Are you Sure you want to Delete?')"
                           href="deletepackage.php?q=<?php echo $religion[0]; ?>"><i class="fa fa-trash"></i></a>
                    </td>
                    <td><a href="editpackage.php?q=<?php echo $religion[0]; ?>"><i class="fa fa-edit"></i></a></td>
                </tr>
                <?php

            }
        } else {
            ?>
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-danger">No Data Found <span class="close"
                                                                        data-dismiss="alert">&times;</span></div>
                </div>
            </div>
            <?php
        }
        ?>
        </tbody>
    </table>
    <div class="row form-group col-md-8 justify-content-center offset-2">
        <?php
        if (isset($_REQUEST['er'])) {
            $val = $_REQUEST['er'];
            if ($val == 0) {
                echo '<div class="alert alert-success">
                        Package Updated Successfully
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
            } elseif ($val == 1) {
                echo '<div class="alert alert-danger">
                        Try Again Later
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
            } elseif ($val == 2) {
                echo '<div class="alert alert-warning">
                      Image extension must be jpg or png format
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
            } elseif ($val == 3) {
                echo '<div class="alert alert-warning">
                            Image size must be less than 200 kb
                          <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
            } elseif ($val == 4) {
                echo '<div class="alert alert-warning">
                        Package Image must be less than 200 kb
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
            } elseif ($val == 5) {
                echo '<div class="alert alert-warning">
                        Package Deleted Successfully
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
            } elseif ($val == 6) {
                echo '<div class="alert alert-warning">
                        Package Deletion Failed
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
            }
        }
        ?>
    </div>

</div>
<?php
include_once 'footer.php';
?>
</body>
</html>
<?php
