<?php
ob_start();
include_once "connect.php";
@session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    $sel = "select * from admin where username='$username'";
    $result = mysqli_query($conn, $sel);
    $row = mysqli_fetch_array($result);
} else {
    header("location:loginpage.php");
}
?>
<?php
include "connect.php";
?>
<div class="header-top">
    <div class="container">
        <div class="w3layouts-address">
            <ul>
                <li><i class="fa fa-phone" aria-hidden="true"></i> +91 844 740 3460</li>
                <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="mailto:info@example.com">
                        sumit.katharia@twominds.co.in</a></li>
            </ul>
        </div>
        <div class="agileinfo-social-grids">
            <ul>
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-rss"></i></a></li>
                <li><a href="#"><i class="fa fa-vk"></i></a></li>
            </ul>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<!-- //header-top -->
<!-- header -->
<div class="header">
    <div class="container-fluid">
        <nav class="navbar navbar-default">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="w3layouts-logo">
                    <h1><a href="index.php"> <span>Two Minds Technology</span></a></h1>
                </div>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
                <nav>
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="index.php">Home</a></li>
                        <!--                        <li><a href="show_admin.php" class="hvr-sweep-to-bottom">View Admin</a></li>-->
                        <?php
                        if ($row['type'] == "Super Admin") {
                            ?>

                            <li class="dropdown">
                                <a class="dropdown-toggle hvr-sweep-to-bottom" data-toggle="dropdown">
                                    Salary Disburse
                                </a>
                                <ul class="nav navbar-nav dropdown-menu">
                                    <li><a class="hvr-sweep-to-bottom" href="addsalarydisbursement.php">Add Salary
                                            Disburse</a></li>
                                    <li><a class="hvr-sweep-to-bottom" href="showsalarydisburse.php">View Salary
                                            Disburse</a></li>
                                </ul>
                            </li>

                            <li class="dropdown">
                                <a class="dropdown-toggle hvr-sweep-to-bottom" data-toggle="dropdown">
                                    Admin
                                </a>
                                <ul class="nav navbar-nav dropdown-menu">
                                    <li><a class="hvr-sweep-to-bottom" href="add_admin.php">Add Admin</a></li>
                                    <li><a class="hvr-sweep-to-bottom" href="show_admin.php">View Admin</a></li>
                                </ul>
                            </li>
                            <?php
                        }
                        ?>
                        <li class="dropdown">
                            <a class="dropdown-toggle hvr-sweep-to-bottom" data-toggle="dropdown">
                                Packages
                            </a>
                            <ul class="nav navbar-nav dropdown-menu">
                                <li><a class="hvr-sweep-to-bottom" href="addpackage.php">Add Package</a></li>
                                <li><a class="hvr-sweep-to-bottom" href="showpackage.php">View Package</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a class="dropdown-toggle hvr-sweep-to-bottom" data-toggle="dropdown">
                                Pricing
                            </a>
                            <ul class="nav navbar-nav dropdown-menu">
                                <li><a class="hvr-sweep-to-bottom" href="addpricing.php">Add Pricing</a></li>
                                <li><a class="hvr-sweep-to-bottom" href="showpricing.php">View Pricing</a></li>
                            </ul>
                        </li>

                        <li><a href="New-discussionByadmin.php" class="hvr-sweep-to-bottom">New Discussion</a></li>
                        <li><a href="showproblem.php" class="hvr-sweep-to-bottom">Customer Problems</a></li>
                        <li><a href="allorder.php" class="hvr-sweep-to-bottom">All Orders</a></li>
                        <li class="dropdown">
                            <a class="dropdown-toggle hvr-sweep-to-bottom" data-toggle="dropdown">
                                <?php if (isset($_SESSION['username'])) {
                                    echo "WELCOME , " . $_SESSION['username'];
                                } ?>
                            </a>
                            <ul class="nav navbar-nav dropdown-menu">
                                <li><a class="hvr-sweep-to-bottom" href="viewadminprofile.php">View Profile</a></li>
                                <li><a class="hvr-sweep-to-bottom" href="viewadminsalary.php">My Salary Disburse</a></li>
                                <li><a class="hvr-sweep-to-bottom" href="admin_changepassword.php">Change Password</a>
                                </li>
                                <?php if (isset($_SESSION['username'])) { ?>
                                    <li><a class="hvr-sweep-to-bottom" href="adminlogout.php">Logout</a></li>
                                <?php } ?>
                            </ul>
                        </li>

                        <!--                        <li><a href="admin_changepassword.php" class="hvr-sweep-to-bottom">Change Password</a></li>-->

                        <!--                        <li class="text-danger"><a class="hvr-sweep-to-bottom">-->
                        <?php //if (isset($_SESSION['username'])) {
                        //                                    echo "WELCOME " . $_SESSION['username'];
                        //                                } ?><!--</a></li>-->
                        <!--                        --><?php //if (isset($_SESSION['username'])) { ?>
                        <!--                            <li><a class="hvr-sweep-to-bottom" href="adminlogout.php">Logout</a></li>-->
                        <!--                        --><?php //} ?>
                    </ul>
                </nav>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
    </div>
</div>




















