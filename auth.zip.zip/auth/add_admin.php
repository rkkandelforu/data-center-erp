<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include 'headerfiles.php';
    ?>
</head>
<body>
<?php
include_once 'adminheader.php';
?>

<div class="about-heading">
    <h2>Two Minds <span> Technology</span></h2>
</div>
<!-- //about-heading -->
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <h3>Admin Registration Form</h3>
            <div class="login-form">
                <form action="insertadmin.php" id="form1" method="post">
                    <div class="row">
                        <div class="col-sm-6">
                            <input type="email" name="email" id="email" placeholder="enter your email address"
                                   data-rule-required="true" data-msg-required="Please enter a valid email address">
                            <input type="text" name="username" id="username"
                                   placeholder="enter username"
                                   data-rule-required="true" data-msg-required="Please enter an unique username">
                            <input type="text" name="mobile" id="mobile"
                                   placeholder="enter a valid mobile number"
                                   data-rule-required="true" data-msg-required="Please enter a valid mobile number"
                                   minlength="10" maxlength="12">
                            <input type="password" name="password" id="password"
                                   placeholder="enter secure password"
                                   data-rule-required="true" data-msg-required="Please enter password">
                            <input type="password" name="conpassword" id="conpassword"
                                   placeholder="enter confirm password"
                                   data-rule-required="true" data-msg-required="Please enter confirm password"
                                   data-rule-equalto="#password"
                                   data-msg-equalto="Password and confirm password must be same">
                            <input type="text" name="designation" id="designation" placeholder="enter designation"
                                   data-rule-required="true" data-msg-required="Please enter designation">
                        </div>
                        <div class="col-sm-6">
                            <select data-rule-required="true" name="type" id="type" class="form-control">
                                <option value="">Select Type</option>
                                <option value="Super Admin">Super Admin</option>
                                <option value="Sub Admin">Sub Admin</option>
                            </select>
                            <input type="text" name="fullname" id="fullname"
                                   placeholder="enter your name"
                                   data-rule-required="true" data-msg-required="Please enter name">
                            <input type="text" name="fathername" id="fathername" placeholder="enter your father name"
                                   data-rule-required="true" data-msg-required="Please enter father name">
                            <input type="text" name="salary" id="salary" placeholder="enter monthly salary"
                                   data-rule-required="true" data-rule-number="true"
                                   data-msg-required="Please enter monthly salary">
                            <textarea name="address" id="address" data-rule-required="true" placeholder="enter address" rows="5"></textarea>
                        </div>
                    </div>
                    <div class="tp">
                        <input type="submit" name="submit" value="Add Admin">
                    </div>
                </form>
            </div>

            <?php
            if (isset($_REQUEST['er'])) {
                $val = $_REQUEST['er'];
                if ($val == 1) {
                    echo '<div class="alert alert-success">
             Admin added Successfully   
             <span class="close" data-dismiss="alert">&times;</span>
             </div>';
                } elseif ($val == 2) {
                    echo '<div class="alert alert-danger">
            Admin insert failed
            <span class="close" data-dismiss="alert">&times;</span>
            </div>';
                } elseif ($val == 0) {
                    echo '<div class="alert alert-info">
            Admin Already exist
            <span class="close" data-dismiss="alert">&times;</span>
            </div>';
                }
            }
            ?>
        </div>
    </div>
</div>

<?php
include_once 'footer.php';
?>
</body>
</html>
