<?php
session_start();
include_once 'connect.php';
$userid = $_SESSION["id"];
$replytext = $_POST["replytext"];
$desc = $_POST["desc"];
$discussionid = $_POST["discussionid"];
$photopath = '';
$videopath = '';
$erro = '';
if ($_FILES["rphoto"]["tmp_name"] != "") {
    $filename = $_FILES["rphoto"]["name"];
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    if ($ext == "jpg" || $ext == "png") {
        $error = "jpg file or png file";
    } else {


        $photopath = "discussiondata/$filename";
        move_uploaded_file($_FILES["rphoto"]["tmp_name"], $photopath);

    }


}

if ($_FILES["rvideo"]["tmp_name"] != "") {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    if ($ext == "mp4") {
        $error = "mp4 file";
    } else {
        $videopath = "discussiondata/$filename";
        move_uploaded_file($_FILES["rvideo"]["tmp_name"], $photopath);

    }
}
if ($erro == "") {
    $qury = "INSERT INTO `discussion_forum_reply`(`replyid`, `customerid`, `discussionid`, `replytext`, `replyimage`, `replyvideourl`) 
VALUES (null,'$userid','$discussionid','$replytext','$photopath','$videopath')";
    echo $qury;
    if (mysqli_query($conn, $qury)) {
        //echo "Insert Success";
      header("Location:discussion-forum.php?er=1&did=$discussionid");
    } else {
        //echo "Insert Failed";
        header("Location:discussion-forum.php?er=2&did=$discussionid");
    }

}else{
    header("Location:discussion-forum.php?er=$erro&did=$discussionid");
}