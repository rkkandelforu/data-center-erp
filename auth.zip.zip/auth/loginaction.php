<?php
include_once "connect.php";
session_start();
if(isset($_POST['submit'])){

    $email = $_REQUEST['email'];
    $pass = $_REQUEST['password'];

    $sql = "SELECT * FROM `users` WHERE email = '$email' AND password= '$pass'";
    echo $sql;
    $res = mysqli_query($conn, $sql);
    $count = mysqli_num_rows($res);

    echo $count;

    if($count > 0){
        $_SESSION['email'] = $email;
        $alert = "11";

        echo $_SESSION['email'];
        header('Location: index.php?status='.$alert);
    }else {
        $alert = "00";
        header('Location: index.php?status='.$alert);
    }
}



?>