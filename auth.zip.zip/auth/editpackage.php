<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include 'headerfiles.php';
    ?>
    <script>
        function readandpreview(fileobj, imageid) {
            var firstfile = fileobj.files[0];
            var reader = new FileReader();
            reader.onload = (function (f) {
                return function read(e) {
                    document.getElementById(imageid).src = e.target.result;
                    document.getElementById(imageid).style.display = "flex";
                }
            })(firstfile);
            reader.readAsDataURL(firstfile);
        }
    </script>
</head>
<body>
<?php
include_once 'adminheader.php';
include_once 'connect.php';
$id = $_REQUEST["q"];
$query = "select * from package where packageid='$id'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

//print_r($row);
?>

<div class="about-heading">
    <h2>Two Minds <span> Technology</span></h2>
</div>
<!-- //about-heading -->
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <h3>Edit Package Form</h3>
            <div class="login-form">
                <form action="updatepackage.php" id="form1" method="post" enctype="multipart/form-data">

                    <div class="rows col-md-8k justify-content-center1 offset-1k">
                        <img src="<?php echo $row["photo"];?>" class="img-fluid" style="height: 200px;width: 200px;" id="showimg" alt="">
                    </div>
                    <div class="row form-group justify-content-center offset-1">
                        <label for="category" class="font-weight-bolder"><u>Category</u></label>
                        <input type="hidden" name="id" id="id" readonly value="<?php echo $row['packageid'];?>">
                        <select type="text" name="category" id="category" data-rule-required="true"
                                data-msg-required="Category selection is mandatory" class="form-control">
                            <option value="">Select category</option>
                            <option <?php if ($row['category'] == 'Hosting') { ?>selected<?php } ?>>Hosting</option>
                            <option <?php if ($row['category'] == 'Domains') { ?>selected<?php } ?>>Domains</option>
                            <option <?php if ($row['category'] == 'VPN') { ?>selected<?php } ?>>VPN</option>
                            <option <?php if ($row['category'] == 'Storage') { ?>selected<?php } ?>>Storage</option>
                        </select>
                    </div>
                    <div class="row form-groupk justify-content-center offset-1">
                        <label for="packagename" class="font-weight-bolder"><u>Package Name</u></label>
                        <input type="text" name="packagename" id="packagename" data-rule-required="true" value="<?php echo $row["packagename"];?>"
                               data-msg-required="Package name is mandatory" placeholder="enter package name" class="input-field">
                    </div>
                    <div class="row form-group justify-content-center offset-1">
                        <label for="symbol" class="font-weight-bolder"><u>Package Symbol</u></label>
                        <input type="file" name="symbol" id="symbol" data-rule-extension="jpg|png|gif" class="form-control"
                               onchange="readandpreview(this,'showimg')">
                    </div>
                    <div class="row form-group justify-content-center offset-1">
                        <label for="description" class="font-weight-bolder"><u>Package Description</u></label>
                        <textarea name="description" id="description" data-rule-required="true"
                                  data-msg-required="Description must be entered" class="input-field" cols="20" rows="5"
                                  placeholder="enter package description "><?php echo $row["description"];?></textarea>
                    </div>
                    <div class="tp">
                        <input type="submit" name="submit" value="Save Changes">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
include_once 'footer.php';
?>
</body>
</html>
