<?php include_once "connect.php"; ?>

    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <?php
        include 'headerfiles.php';
        ?>
    </head>
    <body>
    <?php
    include_once 'adminheader.php';
    ?>
    <br>


    <div class="container">
        <div class="row justify-content-around">
            <h2>View Pricing</h2>
        </div>
        <div class="row col-sm-8 col-lg-offset-2">
            <label for="category" class="">Select Package</label>
            <select name="category" class="form-control" id="category" onchange="show_pricing(this.value)">
                <option value="">Select Category</option>
                <?php
                $qury = "select * from package";
                $res = mysqli_query($conn, $qury);
                while ($category = mysqli_fetch_assoc($res)) {
                    ?>
                    <option value="<?php echo $category["packageid"]; ?>"><?php echo $category["packagename"]; ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <table class="table table-striped table-bordered">
            <thead>
            <tr>
                <th>Sr no.</th>
                <th>Category</th>
                <th>Package Name</th>
                <th>Amount</th>
                <th>Duration</th>
                <th>Offer (in %)</th>
                <th>Update</th>
                <th>Delete</th>

            </tr>
            </thead>
            <tbody id="pricing">
            </tbody>
        </table>
        <?php
        if (isset($_GET['er'])) {
            $msg = $_GET["er"];
            if ($msg == 0) {
                echo "<script>alert('Pricing Deleted Successfully')</script>";
            } elseif ($msg == 1) {
                echo "<script>alert('Failed to delete Pricing')</script>";
            } elseif ($msg == 3) {
                echo "<script>alert('Failed to Update Pricing')</script>";
            } elseif ($msg == 2) {
                echo "<script>alert('Pricing Updated Successfully')</script>";
            }
        }
        ?>
    </div>
    <?php
    include_once 'footer.php';
    ?>

    <script>
        function show_pricing(str) {
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    // alert(this.responseText);
                    document.getElementById("pricing").innerHTML = this.responseText;
                }
            };
            if (str == '') {
                xmlhttp.open("GET", "getpricing.php", true);
            } else {
                xmlhttp.open("GET", "getpricing.php?q=" + str, true);
            }
            xmlhttp.send();
        }

        $(document).ready(function () {
            show_pricing('');
        })
    </script>

    </body>
    </html>
<?php
