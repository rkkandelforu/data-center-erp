<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include_once 'headerfiles.php';
    ?>
    <link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
include_once 'adminheader.php';
?>
<div class="about-heading">
    <h2>Salary <span> Disburse</span> @<span>Two </span>Minds <span> Technology</span></h2>
</div>
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <div class="login-form">
                <h3>Salary Disburse Form</h3>
                <form action="insertsalarydisbursement.php" id="form1" method="post">
                    <div class="form-group">
                        <select data-rule-required="true" name="adminid" class="form-control" id="adminid" onchange="show_salary(this.value)">
                            <option value="">Select Admin</option>
                            <?php
                            $sql = "select username,fullname from admin";
                            $result = mysqli_query($conn, $sql);
                            while ($row = mysqli_fetch_array($result)) {
                                ?>
                                <option value="<?php echo $row["username"]; ?>"><?php echo $row["fullname"]; ?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group" id="salaryinput">
                        <label for="">Salary</label>
                        <input type="text" name="salary" id="salary" readonly>
                    </div>
                    <div class="form-group">
                        <label for="">Perks</label>
                        <input type="text" name="perk" id="perk" data-rule-number="true">
                    </div>
                    <div class="form-group">
                        <label>Year:</label> <select name="year" id="year" class="yrselectdesc form-control"></select>

                    </div>
                    <div class="form-group">
                        <label for="">Month</label>
                        <select data-rule-required="true" name="month" id="month" class="form-control">
                            <option value="">Select Month</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Submit" class="btn btn-block">
                    </div>
                </form>
            </div>
        </div>
        <?php
        if (isset($_REQUEST['er'])) {
            $val = $_REQUEST['er'];
            if ($val == 1) {
                echo '<div class="alert alert-success">
             Salary added Successfully   
             <span class="close" data-dismiss="alert">&times;</span>
             </div>';
            } elseif ($val == 2) {
                echo '<div class="alert alert-danger">
            Salary insert failed
            <span class="close" data-dismiss="alert">&times;</span>
            </div>';
            } elseif ($val == 0) {
                echo '<div class="alert alert-info">
            Salary Already Added
            <span class="close" data-dismiss="alert">&times;</span>
            </div>';
            }
        }
        ?>
    </div>
</div>
<?php
include_once 'footer.php';
?>
<script src="js/year-select.js"></script>
<script type="text/javascript">
    $(document).ready(function (e) {
        $('.yrselectdesc').yearselect({step: 1, order: 'desc'});
    });
</script>
<script>
    function show_salary(str) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("salaryinput").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET", "getsalary.php?q=" + str, true);
        xmlhttp.send();
    }
</script>
</body>
</html>
<?php
