<?php
include_once 'connect.php';

$package = $_POST["package"];
$amount = $_POST["amount"];
$duration = $_POST["duration"];
$offer = $_POST["offer"];
$qury = "select * from pricing where amount='$amount' and duration='$duration' and packageid='$package'";
$result = mysqli_query($conn, $qury);
if (mysqli_num_rows($result) > 0) {
    header("Location:addpricing.php?er=3");
} else {
    $qury = "INSERT INTO `pricing`(`pid`, `amount`, `duration`, `offer`, `packageid`) VALUES (null ,'$amount','$duration','$offer','$package')";
    if (mysqli_query($conn, $qury)) {
        echo "Insert Success";
        header("Location:addpricing.php?er=0");
    } else {
        echo "Insert Failed";
        header("Location:addpricing.php?er=1");
    }
}
