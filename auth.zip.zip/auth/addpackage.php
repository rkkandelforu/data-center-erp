<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include 'headerfiles.php';
    ?>
    <script>
        function readandpreview(fileobj, imageid) {
            var firstfile = fileobj.files[0];
            var reader = new FileReader();
            reader.onload = (function (f) {
                return function read(e) {
                    document.getElementById(imageid).src = e.target.result;
                    document.getElementById(imageid).style.display = "flex";
                }
            })(firstfile);
            reader.readAsDataURL(firstfile);
        }
    </script>
</head>
<body>
<?php
include_once 'adminheader.php';
?>

<div class="about-heading">
    <h2>Two Minds<span> Technology</span></h2>
</div>
<!-- //about-heading -->
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <h3>Add Package Form</h3>
            <div class="login-form">
                <form action="insertpackage.php" id="form1" method="post" enctype="multipart/form-data">
                    <div class="row justify-content-center offset-1">
                        <img src="" class="img-fluid" style="height: 200px;width: 200px;display: none" id="showimg"
                             alt="">
                    </div>
                    <div class="row form-group justify-content-center offset-1">
                        <label for="category" class="font-weight-bolder"><u>Category</u></label>
                        <select type="text" name="category" id="category" data-rule-required="true"
                                data-msg-required="Category selection is mandatory" class="form-control">
                            <option value="">Select category</option>
                            <option value="Hosting">Hosting</option>
                            <option value="Domains">Domains</option>
                            <option value="VPN">VPN</option>
                            <option value="Storage">Storage</option>
                        </select>
                    </div>
                    <div class="row form-group justify-content-center offset-1">
                        <label for="packagename" class="font-weight-bolder"><u>Package Name</u></label>
                        <input type="text" name="packagename" id="packagename" data-rule-required="true"
                               data-msg-required="Package name is mandatory" placeholder="enter package name"
                               class="input-field">
                    </div>
                    <div class="row form-group justify-content-center offset-1">
                        <label for="symbol" class="font-weight-bolder"><u>Package Symbol</u></label>
                        <input type="file" name="symbol" id="symbol" data-rule-required="true"
                               data-rule-extension="jpg|png|gif"
                               data-msg-required="Package Symbol is mandatory" class="form-control"
                               onchange="readandpreview(this,'showimg')">
                    </div>
                    <div class="row form-group justify-content-center offset-1">
                        <label for="description" class="font-weight-bolder"><u>Package Description</u></label>
                        <textarea name="description" id="description" data-rule-required="true"
                                  data-msg-required="Description must be entered" class="input-field" cols="20" rows="5"
                                  placeholder="enter package description "></textarea>
                    </div>

                    <div class="tp">
                        <input type="submit" name="submit" value="Add Package">
                    </div>
                </form>
            </div>

            <div class="row form-group col-md-8 justify-content-center offset-2">
                <?php
                if (isset($_REQUEST['er'])) {
                    $val = $_REQUEST['er'];
                    if ($val == 0) {
                        echo '<div class="alert alert-success">
                        Package Added Successfully
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                    } elseif ($val == 1) {
                        echo '<div class="alert alert-danger">
                        Try Again Later
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                    } elseif ($val == 2) {
                        echo '<div class="alert alert-warning">
                        Image size must be less than 100 kb
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                    } elseif ($val == 3) {
                        echo '<div class="alert alert-warning">
                        Package already exists
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                    } elseif ($val == 4) {
                        echo '<div class="alert alert-warning">
                        Package Image must be less than 200 kb
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                    }
                }
                ?>
            </div>

        </div>
    </div>
</div>

<?php
include_once 'footer.php';
?>
</body>
</html>
