<?php
include_once 'connect.php';
if (isset($_GET['q'])) {
    $pack = $_GET['q'];
    $qury = "select * from reply inner join customersupport on reply.csid=customersupport.csid where reply.csid='$pack'";
}
$k = 0;
$result = mysqli_query($conn, $qury);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        $k++;
        ?>
        <tr class="<?php if ($row['replyby'] == 'Customer') {
            echo 'btn-warning';
        } else {
            echo 'btn-info';
        } ?>">
            <td><?php echo $k ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['replyby']; ?></td>
            <td><?php echo $row['replydt']; ?></td>
        </tr>
        <?php
    }
} else {
    ?>
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="alert alert-danger">No Data Found <span class="close"
                                                                data-dismiss="alert">&times;</span></div>
        </div>
    </div>
    <?php
}
?>