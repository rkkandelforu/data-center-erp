<?php

include_once 'connect.php';
session_start();
$email = $_POST["email"];
$password = $_POST["password"];
$qury ="SELECT * FROM `users` WHERE email ='$email' and password = '$password'";
$result = mysqli_query($conn,$qury);
if (mysqli_num_rows($result)>0){
    $row=mysqli_fetch_array($result);
    $_SESSION["email"] =$email;
//    $_SESSION["name"]=
    $_SESSION["id"]=$row[0];
    header("location:userhome.php");
}
else
{
    header("location:userloginpage.php?er=1");
}