function show_pricing(str) {

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            // alert(this.responseText);
            document.getElementById("pricing").innerHTML = this.responseText;
        }
    };
    if (str == '') {
        xmlhttp.open("GET", "getpricing.php", true);
    } else {
        xmlhttp.open("GET", "getpricing.php?q=" + str, true);
    }
    xmlhttp.send();
}