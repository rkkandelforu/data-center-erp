<?php
include_once 'connect.php';
if (isset($_GET['q'])) {
    $pack = $_GET['q'];
    $qury = "select * from customersupport inner join users on users.id=customersupport.postedby where customersupport.category='$pack'";
} else {
    $qury = "select * from customersupport inner join users on users.id=customersupport.postedby";
}
$k = 0;
$result = mysqli_query($conn, $qury);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        $k++;
        ?>
        <tr>
            <td><?php echo $k ?></td>
            <td><img style="height: 150px;width: 250px" src="<?php echo $row["photo"]; ?>" alt=""></td>
            <td><?php echo $row['title']; ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['category']; ?></td>
            <td><?php echo $row['custid']; ?></td>
            <td><a onclick="showmodal('<?php echo $row['csid']; ?>')"><i class="fa fa-reply"></i></a></td>
            <td>
                <button onclick="showstory('<?php echo $row['csid']; ?>')"><i class='fa fa-info-circle'></i>
                </button>
            </td>
        </tr>
        <?php
    }
} else {
    ?>
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="alert alert-danger">No Data Found <span class="close"
                                                                data-dismiss="alert">&times;</span></div>
        </div>
    </div>
    <?php
}
?>