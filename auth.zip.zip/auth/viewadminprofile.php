<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include_once 'headerfiles.php';
    ?>
</head>
<body>
<?php
include_once 'adminheader.php';
?>
<div class="about-heading">
    <h2><span>Admin </span>Profile <span>@</span>Two Minds <span> Technology</span></h2>
</div>
<div class="registration">
    <div class="container">
        <div class="row" style="border-style: inset">
            <div class="col-sm-6" style="border-style: inset">
                <h4>Username</h4>
                <h4>Email</h4>
                <h4>Mobile</h4>
                <h4>Full Name</h4>
                <h4>Father's Name</h4>
                <h4>Account Type</h4>
                <h4>Designation</h4>
                <h4>Monthly Salary</h4>
                <h4>Address</h4>
            </div>
            <div class="col-sm-6" style="border-style: inset">
                <h4 class="text-capitalize"><b><?php echo $row['username']; ?></b></h4>
                <h4><b><?php echo $row['email']; ?></b></h4>
                <h4><b><?php echo $row['mobile']; ?></b></h4>
                <h4 class="text-capitalize"><b><?php echo $row['fullname']; ?></b></h4>
                <h4 class="text-capitalize"><b><?php echo $row['father']; ?></b></h4>
                <h4 class="text-capitalize"><b><?php echo $row['type']; ?></b></h4>
                <h4 class="text-capitalize"><b><?php echo $row['designation']; ?></b></h4>
                <h4>$ <b><?php echo $row['monthlysalary']; ?></b></h4>
                <h4 class="text-capitalize"><b><?php echo $row['address']; ?></b></h4>

            </div>
        </div>
    </div>
</div>
<?php
include_once 'footer.php';
?>
</body>
</html>
<?php
