-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2020 at 10:57 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `auth`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `father` varchar(200) NOT NULL,
  `designation` varchar(500) NOT NULL,
  `address` text NOT NULL,
  `monthlysalary` float NOT NULL,
  `type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `email`, `password`, `mobile`, `fullname`, `father`, `designation`, `address`, `monthlysalary`, `type`) VALUES
('abc', 'necuzyf@mailinator.net', '111', 8701236547, 'Branden Vinson', 'Drupal', 'HRD', 'calefornia', 1000000, 'Super Admin'),
('kuvadeva', 'rulurisoqu@mailinator.com', 'Pa$$w0rd!', 8575896352, 'Darrel Neal', 'Thor Alvarez', 'Manager', 'gangland', 45000, 'Sub Admin'),
('manisha', 'manisha@gmail.com', '111', 7009741717, 'manisha kumari', 'manish kumar', 'ceo', 'syndicate', 70000, 'Sub Admin'),
('micikixu', 'liwezer@mailinator.com', 'Pa$$w0rd!', 7009741717, 'Chaney Pruitt', 'Wilma Gentry', 'Technical Specialist', 'Amet itaque dolorem', 35000, 'Super Admin'),
('mizexabyf', 'gamobepyt@mailinator.net', 'Pa$$w0rd!', 6283069142, 'Mariko Erickson', 'Tashya Johnston', 'Qui eveniet distinc', 'Corrupti consequunt', 71000, 'Sub Admin'),
('pyvubyjel', 'jonapo@mailinator.net', 'Pa$$w0rd!', 0, 'Mason Mack', 'Hoyt Duran', 'Dolores do dolor ips', 'Pariatur Dolor cupi', 70062, 'Sub Admin');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `billid` int(11) NOT NULL,
  `total` float NOT NULL,
  `datetime` datetime NOT NULL,
  `custid` int(11) NOT NULL,
  `pricingid` int(11) NOT NULL,
  `dateofexpiry` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`billid`, `total`, `datetime`, `custid`, `pricingid`, `dateofexpiry`) VALUES
(2, 4500, '2020-05-28 00:00:00', 4, 1, '2020-08-28'),
(3, 957.39, '2020-05-28 15:52:44', 3, 4, '2027-01-28'),
(4, 957.39, '2020-05-28 16:02:01', 4, 4, '2027-01-28'),
(5, 4500, '2020-05-28 16:03:18', 4, 1, '2020-08-28'),
(7, 4500, '2020-05-28 16:04:13', 5, 1, '2020-08-28'),
(9, 4500, '2020-05-28 16:06:59', 4, 1, '2020-08-28'),
(10, 4140, '2020-05-28 16:07:56', 4, 3, '2021-02-28'),
(12, 4140, '2020-05-28 16:08:48', 4, 3, '2021-02-28'),
(14, 1128, '2020-05-28 16:12:47', 4, 5, '2021-07-28'),
(15, 1128, '2020-05-29 16:17:08', 4, 5, '2021-07-29'),
(16, 3312, '2020-05-29 16:25:04', 4, 7, '2023-05-29'),
(17, 1764, '2020-05-31 11:14:46', 4, 6, '2020-12-01'),
(18, 7091.55, '2020-06-11 16:42:47', 4, 8, '2021-09-11');

-- --------------------------------------------------------

--
-- Table structure for table `customersupport`
--

CREATE TABLE `customersupport` (
  `csid` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `category` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `photo` varchar(500) NOT NULL,
  `postedby` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customersupport`
--

INSERT INTO `customersupport` (`csid`, `title`, `category`, `description`, `photo`, `postedby`) VALUES
(2, 'Eligendi aperiam qui', 'Technical Ticket', 'Modi in dolore lauda', 'photos/5.jpg', 4),
(3, 'Non pariatur Verita', 'Sales Ticket', 'Praesentium adipisci', 'photos/15.jpg', 4),
(4, 'Blanditiis corrupti', 'Technical Ticket', 'Praesentium architec', 'photos/24.jpg', 4),
(5, 'Lorem provident dol', 'Sales Ticket', 'Occaecat labore ulla', 'photos/bg3.jpg', 4),
(6, 'Neque molestiae et q', 'Technical Ticket', 'Aute maxime ex fugia', 'photos/51.jpg', 4),
(7, 'Domain Verification', 'Technical Ticket', 'have trouble while domain verification ', 'photos/30.jpg', 4),
(8, 'Elit aliquam labori', 'Technical Ticket', 'Laboris ad quibusdam', 'photos/4.png', 4),
(9, 'Corporis et aut pers', 'Technical Ticket', 'Minim voluptate volu', 'photos/19.jpg', 4),
(10, 'Eveniet amet non q', 'Technical Ticket', 'Et et et laborum Qu', 'photos/b3.jpg', 4);

-- --------------------------------------------------------

--
-- Table structure for table `discussion_forum`
--

CREATE TABLE `discussion_forum` (
  `id` int(11) NOT NULL,
  `title` varchar(300) NOT NULL,
  `detail` text NOT NULL,
  `postedby` varchar(50) NOT NULL,
  `postdate` datetime NOT NULL DEFAULT current_timestamp(),
  `customerid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `discussion_forum`
--

INSERT INTO `discussion_forum` (`id`, `title`, `detail`, `postedby`, `postdate`, `customerid`) VALUES
(1, 'zfsdf', 'fdsfdsgsg', 'admin', '2020-05-22 18:31:18', NULL),
(3, 'Corporate Web Administrator', 'Repellendus consequatur ut est amet odio saepe.', 'admin', '2020-05-23 15:57:32', NULL),
(4, 'Saepe cupiditate necessitatibus nam odit praesentium quam. Sed in facilis eum esse ut placeat repudiandae eum et. Pariatur aut voluptates ipsa sint optio eum illum vitae sunt.', 'Et ut illum porro dolor ea. Ipsam et quod ab ut quia. Odit velit dolores sunt laborum sapiente sint odio ut.', 'admin', '2020-05-23 15:58:25', NULL),
(5, '', '', 'abc', '2020-05-27 13:37:01', NULL),
(6, 'Provident laboris m', 'Neque sunt deserunt ', 'abc', '2020-05-27 13:37:36', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `discussion_forum_reply`
--

CREATE TABLE `discussion_forum_reply` (
  `replyid` int(11) NOT NULL,
  `customerid` int(11) DEFAULT NULL,
  `discussionid` int(11) NOT NULL,
  `replytext` text NOT NULL,
  `replyimage` varchar(200) NOT NULL,
  `replyvideourl` varchar(200) NOT NULL,
  `replydate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `discussion_forum_reply`
--

INSERT INTO `discussion_forum_reply` (`replyid`, `customerid`, `discussionid`, `replytext`, `replyimage`, `replyvideourl`, `replydate`) VALUES
(1, 0, 3, 'zfzfsf', '', '', '2020-05-23 18:01:51'),
(2, 0, 1, '', '', '', '2020-05-23 18:02:50'),
(3, 0, 1, 'zdszdsa', '', '', '2020-05-23 18:04:49'),
(4, 1, 1, '', '', '', '2020-05-23 19:27:26'),
(5, 4, 5, 'Dolor itaque eaque m', '', '', '2020-06-11 16:39:12');

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `packageid` int(11) NOT NULL,
  `packagename` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `photo` varchar(500) NOT NULL,
  `category` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`packageid`, `packagename`, `description`, `photo`, `category`) VALUES
(2, 'Mia Bright', 'Inventore eu fugit ', 'photos/deserts.jpg', 'VPN'),
(4, 'Orson Pierce', 'Laboriosam sit dol', 'photos/7.jpg', 'Domains'),
(5, 'Grant Moon', 'Voluptas enim Nam es', 'photos/icon6.png', 'Storage'),
(6, 'Wing Bishop', 'Fugiat ea quas nisi ', 'photos/left-arrow.png', 'Domains'),
(7, 'Moana Long', 'Ad dolore hic doloru', 'photos/9.jpg', 'Hosting'),
(8, 'Upton West', 'Suscipit molestiae q', 'photos/cart.png', 'Storage'),
(9, 'Kareem mcaffe', 'Commodi amet quia i', 'photos/banner1.png.jpg', 'VPN'),
(10, 'Sybill Underwood', 'Et dolor provident ', 'photos/icon2.png', 'Domains'),
(11, 'Julian Spears', 'Totam nulla incidunt', 'photos/download.png', 'Domains');

-- --------------------------------------------------------

--
-- Table structure for table `pricing`
--

CREATE TABLE `pricing` (
  `pid` int(11) NOT NULL,
  `amount` float NOT NULL,
  `duration` varchar(500) NOT NULL,
  `offer` varchar(500) NOT NULL,
  `packageid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pricing`
--

INSERT INTO `pricing` (`pid`, `amount`, `duration`, `offer`, `packageid`) VALUES
(1, 5000, '3', '10', 8),
(3, 4500, '9', '8', 5),
(4, 987, '80', '3', 2),
(5, 1200, '14', '6', 5),
(6, 1800, '6', '2', 9),
(7, 3600, '36', '8', 9),
(8, 8755, '15', '19', 10),
(9, 1200, '5', '8', 2);

-- --------------------------------------------------------

--
-- Table structure for table `reply`
--

CREATE TABLE `reply` (
  `replyid` int(11) NOT NULL,
  `replydt` datetime NOT NULL,
  `description` text NOT NULL,
  `csid` int(11) NOT NULL,
  `replyby` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reply`
--

INSERT INTO `reply` (`replyid`, `replydt`, `description`, `csid`, `replyby`) VALUES
(1, '2020-06-20 10:58:12', 'Qui non dolore saepe', 3, 'Customer'),
(2, '2020-06-20 10:59:15', 'Quia rem sequi molli', 3, 'CSE'),
(3, '2020-06-20 10:59:27', 'Ab facilis aut itaqu', 3, 'CSE'),
(4, '2020-06-20 10:59:31', 'Dolores ut id ducim', 2, 'Customer'),
(5, '2020-06-20 10:59:36', 'Sed fugiat modi volu', 6, 'Customer'),
(6, '2020-06-20 10:59:41', 'Dicta eu quo esse vo', 7, 'CSE'),
(7, '2020-06-20 12:55:53', 'Est provident offi', 8, 'CSE'),
(8, '2020-06-20 12:58:39', 'Veritatis fugiat mod', 3, 'Customer'),
(9, '2020-06-20 13:02:42', 'Voluptatem quia faci', 2, 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `salary_disburse`
--

CREATE TABLE `salary_disburse` (
  `sdid` int(11) NOT NULL,
  `dateofdisbursement` date NOT NULL,
  `salary` float NOT NULL,
  `perks` float NOT NULL,
  `month` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `adminid` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salary_disburse`
--

INSERT INTO `salary_disburse` (`sdid`, `dateofdisbursement`, `salary`, `perks`, `month`, `year`, `adminid`) VALUES
(1, '2020-06-05', 35000, 5450, 'July', 2020, 'micikixu'),
(2, '2020-06-05', 70000, 777, 'December', 1987, 'manisha'),
(3, '2020-06-05', 45000, 1132, 'January', 2007, 'kuvadeva'),
(4, '2020-06-05', 1000000, 220, 'February', 1994, 'abc'),
(5, '2020-06-11', 35000, 7000, 'April', 2005, 'micikixu');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(15) NOT NULL,
  `custid` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(80) NOT NULL,
  `mobile_number` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `custid`, `email`, `password`, `mobile_number`, `gender`) VALUES
(1, '212', 'singh@gmail.com', '1122', '6283069142', 'male'),
(2, '57757', 'ss@gmail.com', '1122', '7009741717', 'female'),
(3, '3223', 'demo@gmail.com', '1122', '6280276218', 'male'),
(4, 'Mollitia odio deseru', 'parwindersingh@vmmeducation.com', '111', '9855447487', 'male'),
(5, '4566', 'abc@def.com', '111', '7973500986', 'male'),
(6, '1455', 'biwem@mailinator.net', 'Pa$$w0rd!', '6283069142', 'male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`billid`),
  ADD KEY `custid` (`custid`),
  ADD KEY `pricingid` (`pricingid`);

--
-- Indexes for table `customersupport`
--
ALTER TABLE `customersupport`
  ADD PRIMARY KEY (`csid`),
  ADD KEY `postedby` (`postedby`);

--
-- Indexes for table `discussion_forum`
--
ALTER TABLE `discussion_forum`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discussion_forum_reply`
--
ALTER TABLE `discussion_forum_reply`
  ADD PRIMARY KEY (`replyid`),
  ADD KEY `discussionid` (`discussionid`),
  ADD KEY `customerid` (`customerid`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`packageid`);

--
-- Indexes for table `pricing`
--
ALTER TABLE `pricing`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `packegeid` (`packageid`);

--
-- Indexes for table `reply`
--
ALTER TABLE `reply`
  ADD PRIMARY KEY (`replyid`),
  ADD KEY `csid` (`csid`);

--
-- Indexes for table `salary_disburse`
--
ALTER TABLE `salary_disburse`
  ADD PRIMARY KEY (`sdid`),
  ADD KEY `adminid` (`adminid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `billid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `customersupport`
--
ALTER TABLE `customersupport`
  MODIFY `csid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `discussion_forum`
--
ALTER TABLE `discussion_forum`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `discussion_forum_reply`
--
ALTER TABLE `discussion_forum_reply`
  MODIFY `replyid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `packageid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pricing`
--
ALTER TABLE `pricing`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `reply`
--
ALTER TABLE `reply`
  MODIFY `replyid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `salary_disburse`
--
ALTER TABLE `salary_disburse`
  MODIFY `sdid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bill`
--
ALTER TABLE `bill`
  ADD CONSTRAINT `bill_ibfk_1` FOREIGN KEY (`custid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bill_ibfk_2` FOREIGN KEY (`pricingid`) REFERENCES `pricing` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customersupport`
--
ALTER TABLE `customersupport`
  ADD CONSTRAINT `customersupport_ibfk_1` FOREIGN KEY (`postedby`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `discussion_forum_reply`
--
ALTER TABLE `discussion_forum_reply`
  ADD CONSTRAINT `discussion_forum_reply_ibfk_1` FOREIGN KEY (`discussionid`) REFERENCES `discussion_forum` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pricing`
--
ALTER TABLE `pricing`
  ADD CONSTRAINT `pricing_ibfk_1` FOREIGN KEY (`packageid`) REFERENCES `package` (`packageid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reply`
--
ALTER TABLE `reply`
  ADD CONSTRAINT `reply_ibfk_1` FOREIGN KEY (`csid`) REFERENCES `customersupport` (`csid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `salary_disburse`
--
ALTER TABLE `salary_disburse`
  ADD CONSTRAINT `salary_disburse_ibfk_1` FOREIGN KEY (`adminid`) REFERENCES `admin` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
