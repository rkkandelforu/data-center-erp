<?php
include 'adminheader.php';
include_once 'connect.php';

$username = $_POST["username"];
$email = $_POST["email"];
$mobile = $_POST["mobile"];
$fullname = $_POST["fullname"];
$fathername = $_POST["fathername"];
$designation = $_POST["designation"];
$salary = $_POST["salary"];
$type = $_POST["type"];
$address = $_POST["address"];

$qury = "UPDATE `admin` SET `email`='$email',`mobile`='$mobile',`fullname`='$fullname',`father`='$fathername',`designation`='$designation',`address`='$address',`monthlysalary`='$salary',`type`='$type' WHERE `username`='$username'";
echo $qury;
if (mysqli_query($conn, $qury)) {
    echo "Update Success";
    header("location:show_admin.php?er=2");
} else {
    echo "Update Failed";
    header("location:show_admin.php?er=3");
}
