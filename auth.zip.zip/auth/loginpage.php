<!DOCTYPE html>
<html lang="en">
<head>
    <title>Two Minds Technology</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Hosting City Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <?php include_once "headerfiles.php";?>
</head>
<body>
<?php include_once "navbar.php";?>
<!-- about-heading -->
<div class="about-heading">
    <h2>Two Minds <span> Technology</span></h2>
</div>
<!-- //about-heading -->
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <h3>Login</h3>
            <div class="login-form">
                <form action="checklogin.php" method="post">
                    <input type="text" placeholder="enter username" name="username" id="username" data-rule-required="true">
                    <input type="password" placeholder="enter password" name="password" data-rule-required="true"
                           id="password">
                    <div class="tp">
                        <input type="submit" name="submit" value="LOGIN NOW">
                    </div>
                </form>
            </div>

            <?php
            if (isset($_REQUEST['er'])) {
                $val = $_REQUEST['er'];
                if ($val == 1) {
                    echo '<div class="alert alert-danger">
                        Password changed successfully
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                }
                if ($val == 4) {
                    echo '<div class="alert alert-danger">
                        Invalid User name password
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                }
            }
            ?>
        </div>
    </div>
</div>
<?php include_once "footer.php";?>
</body>
</html>

