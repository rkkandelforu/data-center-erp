<?php
session_start();
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Hosting City a Hosting Category Flat Bootstrap responsive Website Template | Login :: w3layouts</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="Hosting City Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"/>
    <?php include_once "headerfiles.php"; ?>
</head>
<body>
<?php include_once "navbar.php"; ?>
<!-- about-heading -->
<div class="about-heading">
    <h2>Two Minds <span> Technology</span></h2>
</div>
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <h3>Register</h3>
            <div class="text-danger"><?php if (isset($_GET['status'])) {
                    if ($_GET['status'] == 'pass') {
                        echo "Password and Confirm Password not Match";
                    } elseif ($_GET['status'] == 'done') {
                        echo "Register Done";
                    }
                } ?>
            </div>
            <div class="login-form">
                <form action="adminchangepasswordaction.php" method="post">
                    <input type="email" name="email" readonly value="<?php echo $_SESSION['email']; ?>"
                           placeholder="E-mail" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <input type="password" name="newpassword" placeholder=" New  Password" required>
                    <input type="password" name="newconpassword" placeholder="Confirm New Password" required>
                    <input type="submit" name="submit" value="Update">
                </form>
            </div>
        </div>
    </div>
</div>
<?php include_once "footer.php"; ?>
</body>
</html>