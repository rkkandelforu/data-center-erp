<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include 'headerfiles.php';
    ?>
</head>
<body>
<?php
include 'adminheader.php';
include_once 'connect.php';
$username = $_GET['username'];
$query = "select * from admin where username='$username'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
//print_r($row);
?>


<div class="about-heading">
    <h2>Two Minds <span> Technology</span></h2>
</div>
<!-- //about-heading -->
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <h3>Edit Admin</h3>
            <div class="login-form">
                <form action="updateadmin.php" id="form1" method="post">
                    <div class="row">
                        <div class="col-sm-6">
                            <input type="text" name="username" id="username"
                                   placeholder="enter username" readonly
                                   data-rule-required="true" data-msg-required="Please enter an unique username"
                                   class="input-field" value="<?php echo $row["username"]; ?>">
                            <input type="email" value="<?php echo $row['email']; ?>" name="email" id="email"
                                   placeholder="enter your email address"
                                   data-rule-required="true" data-msg-required="Please enter a valid email address"
                                   class="input-field">
                            <input type="text" name="mobile" id="mobile"
                                   placeholder="enter a valid mobile number"
                                   data-rule-required="true" data-msg-required="Please enter a valid mobile number"
                                   class="input-field" minlength="10" maxlength="10"
                                   value="<?php echo $row["mobile"] ?>">
                            <input type="text" name="fullname" id="fullname"
                                   placeholder="enter your name"
                                   data-rule-required="true" data-msg-required="Please enter name"
                                   class="input-field" value="<?php echo $row['fullname'] ?>">
                            <input type="text" name="designation" id="designation" placeholder="enter designation"
                                   data-rule-required="true" data-msg-required="Please enter designation" value="<?php echo $row['designation'];?>">
                        </div>
                        <div class="col-sm-6">
                            <select data-rule-required="true" name="type" id="type" class="form-control">
                                <option value="">Select Type</option>
                                <option <?php if ($row['type'] == 'Super Admin') { ?>selected<?php } ?>>Super Admin</option>
                                <option <?php if ($row['type'] == 'Sub Admin') { ?>selected<?php } ?>>Sub Admin</option>
                            </select>
                            <input type="text" name="fathername" id="fathername" placeholder="enter your father name"
                                   data-rule-required="true" data-msg-required="Please enter father name"
                                   value="<?php echo $row['father'] ?>">
                            <input type="text" name="salary" id="salary" placeholder="enter monthly salary"
                                   data-rule-required="true" data-rule-number="true"
                                   data-msg-required="Please enter monthly salary"
                                   value="<?php echo $row['monthlysalary'] ?>">
                            <textarea name="address" id="address" data-rule-required="true" placeholder="enter address"
                                      rows="5"><?php echo $row['address'] ?></textarea>
                        </div>
                    </div>
                    <div class="tp">
                        <input type="submit" name="submit" value="UPDATE ADMIN">
                    </div>
                </form>
            </div>


        </div>
    </div>
</div>


<div class="main-sec"></div>

<!--<div class="container">-->
<!--    <form action="updateadmin.php" method="post" id="form1" enctype="multipart/form-data">-->
<!--        <div class="row ml-3 justify-content-center">-->
<!--            <div class="input-containder">-->
<!--                <h1 class="text-danger input-field">Edit Your Profile</h1>-->
<!--            </div>-->
<!--        </div>-->
<!---->
<!--        <div class="row mt-3">-->
<!---->
<!--            <div class="col-sm-5 offset-4 mr-3">-->
<!--                <div class="row">-->
<!--                    <div class="input-container">-->
<!--                        <i class="icon fa fa-envelope-square"></i>-->
<!---->
<!--                    </div>-->
<!--                </div>-->
<!---->
<!--                <div class="row">-->
<!--                    <div class="input-container">-->
<!--                        <i class="icon fa fa-user"></i>-->
<!--                    </div>-->
<!--                </div>-->
<!---->
<!--                <div class="row">-->
<!--                    <div class="input-container">-->
<!--                        <i class="icon fa fa-phone-alt"></i>-->
<!---->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="row">-->
<!--                    <div class="input-container">-->
<!--                        <i class="icon fa fa-user-circle"></i>-->
<!---->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!---->
<!---->
<!--        </div>-->
<!--        <div class="row">-->
<!--            <div class="input-container justify-content-center">-->
<!--                <input type="submit" value="submit"-->
<!--                       class="btn btn-success w-25">-->
<!--            </div>-->
<!--        </div>-->
<!---->
<!--    </form>-->
<!---->
<!--</div>-->
<?php
include_once 'footer.php';
?>
</body>
</html>
<?php
