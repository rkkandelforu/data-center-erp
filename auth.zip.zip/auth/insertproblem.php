<?php
include 'userheader.php';
include_once 'connect.php';

$title = $_POST["title"];
$description = $_POST["description"];
$category = $_POST["category"];
$photo = $_FILES["symbol"]["tmp_name"];
$path = '';
$error = "";
if ($photo != "") {
    $filename = $_FILES["symbol"]["name"];
    $ext = pathinfo(strtolower($filename), PATHINFO_EXTENSION);
    if (round($_FILES["symbol"]["size"] / 1024) > 200) {
        $error = "Image size must be less than 200 kb";
        header("location:addproblem.php?er=2");
    } else {
        $path = "photos/$filename";
        move_uploaded_file($photo, $path);
    }
}

if ($error == "") {
    $qury = "INSERT INTO `customersupport`(`csid`, `title`, `category`, `description`, `photo`, `postedby`) VALUES (null,'$title','$category','$description','$path','$user_row[0]')";
    echo $qury;
    if (mysqli_query($conn, $qury)) {
        echo 0;
        header("location:addproblem.php?er=0");
    } else {
        echo 1;
        header("location:addproblem.php?er=1");
    }
} else {
    echo $error;
    header("location:addproblem.php?er=2");
}