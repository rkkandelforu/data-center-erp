<?php

//session_start();


?>

<!-- header-top -->
<div class="header-top">
    <div class="container">
        <div class="w3layouts-address">
            <ul>
                <li><i class="fa fa-phone" aria-hidden="true"></i>+91 844 740 3460</li>
                <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="mailto:info@example.com"> sumit.katharia@twominds.co.in</a></li>
            </ul>
        </div>
        <div class="agileinfo-social-grids">
            <ul>
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-rss"></i></a></li>
                <li><a href="#"><i class="fa fa-vk"></i></a></li>
            </ul>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<!-- //header-top -->
<!-- header -->
<div class="header">
    <div class="container-fluid">
        <nav class="navbar navbar-default">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="w3layouts-logo">
                    <h1><a href="index.php">Two Minds <span>Technology</span></a></h1>
                </div>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
                <nav>
                    <ul class="nav navbar-nav">
                        <li class="active"><a class="hvr-sweep-to-bottom" href="index.php">Home</a></li>
                        <li class=""><a class="hvr-sweep-to-bottom" href="shop.php?q=Hosting">Hosting</a></li>
                        <li class=""><a class="hvr-sweep-to-bottom" href="shop.php?q=Domains">Domains</a></li>
                        <li class=""><a class="hvr-sweep-to-bottom" href="shop.php?q=VPN">VPN</a></li>
                        <li class=""><a class="hvr-sweep-to-bottom" href="shop.php?q=Storage">Storage</a></li>
<!--                        <li><a href="about.html" class="hvr-sweep-to-bottom">About</a></li>-->
                        <?php  if(!isset($_SESSION['email'])) {?>
                        <li><a href="userloginpage.php" class="hvr-sweep-to-bottom">Login</a></li>
                        <li><a href="registration.php" class="hvr-sweep-to-bottom">Register</a></li>
                        <?php } ?>
<!--                        <li><a class="hvr-sweep-to-bottom" href="addproblem.php">Customer Support</a></li>-->
                        <li><a class="hvr-sweep-to-bottom" href="discussion-forum.php">Discussions</a></li>
                        <li><a href="loginpage.php" class="hvr-sweep-to-bottom">Admin Login</a></li>
                        <li class="text-danger"><a class="text-"><?php if(isset($_SESSION['email'])){ echo "WELCOME ".$_SESSION['email']; } ?></a></li>
                        <?php  if(isset($_SESSION['email'])) {?>
                        <li><a class="hvr-sweep-to-bottom" href="logout.php">Logout</a></li>
                        <?php } ?>
                    </ul>
                </nav>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
    </div>
</div>
<!-- //header -->