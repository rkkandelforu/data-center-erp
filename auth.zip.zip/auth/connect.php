<?php
$conn = mysqli_connect('localhost','root',NULL,'auth');

if(!$conn){
    die("connection erro");
}