<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Two Minds Tehnology </title>
    <?php
    ob_start();
    include_once 'headerfiles.php';
    ?>

</head>
<body>
<?php
include_once 'connect.php';
include_once 'navbar.php';
if (isset($_GET['q'])) {
    $category = $_GET['q'];
} else {
    header("Location:index.php");
}
?>
<!-- //header-top -->
<!-- about-heading -->
<div class="about-heading">
    <h2>Our <span>Plans</span></h2>
</div>
<!-- shared-grid -->
<div class="shared-grid">
    <div class="container">
        <div class="w3-banner-bottom-heading">
            <h3><span><?php echo $category; ?> </span></h3>
        </div>
        <div class="priceing-table-main">
            <?php
            $sql = "select * from package where category='$category'";
            $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result)) {
                    ?>
                    <div class="col-md-3 price-grid wthree">
                        <form action="bill.php" method="post">

                            <div class="price-block agile">
                                <div class="price-gd-top pric-clr1">
                                    <h4><?php echo $row["packagename"]; ?></h4>
                                    <select name="pricing" style="color: #d89402" class="form-control">
                                        <?php
                                        $sql2 = "select * from pricing where packageid='$row[0]'";
                                        $result2 = mysqli_query($conn, $sql2);
                                        while ($row2 = mysqli_fetch_array($result2)) {
                                            ?>
                                            <option value="<?php echo $row2['pid']; ?>">
                                                <h5><?php echo $row2["duration"]; ?> months&nbsp;@</h5>
                                                <h3>&nbsp;&#8377;
                                                    <?php
                                                    if (!empty($row2['offer']) && $row2['offer'] > 0) {
                                                        $discountedPrice = $row2['amount'] - ($row2['amount'] * $row2['offer'] / 100);
                                                        echo $discountedPrice;
                                                    } else {
                                                        echo $row2['amount'];
                                                    }
                                                    ?></h3>
                                                &nbsp;

                                                <br>
                                                <p style="font-size: 3px">Save <?php echo $row2["offer"]; ?> %</p>
                                                <?php
                                                if (!empty($row2['offer']) && $row2['offer'] > 0) {
                                                    ?>
                                                    <p style="text-decoration: line-through;display: block">
                                                        (&#8377; <?php echo $row2['amount'] ?>)</p>
                                                    <?php
                                                }
                                                ?>
                                            </option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="price-gd-bottom">
                                    <div class="price-list">
                                        <ul>
                                            <li><img style="height: 100px;width: 130px"
                                                     src="<?php echo $row["photo"]; ?>"
                                                     alt=""></li>
                                            <li><?php echo $row["category"]; ?></li>
                                            <li><?php echo $row["description"]; ?></li>
                                        </ul>
                                    </div>
                                    <div class="price-selet pric-sclr1">
                                        <button type="submit" style="background-color: #55acee">Buy
                                            Now
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    <?php
                }
            }
            ?>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php
include_once 'footer.php';
?>
</body>
</html>