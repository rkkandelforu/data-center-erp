<?php
include 'adminheader.php';
include_once 'connect.php';

if (isset($_POST['id'])) {

    $id = $_POST['id'];
    $package = $_POST["package"];
    $amount = $_POST["amount"];
    $duration = $_POST["duration"];
    $offer = $_POST["offer"];

    $qury = "UPDATE `pricing` SET `amount`='$amount',`duration`='$duration',`offer`='$offer',`packageid`='$package' WHERE `pid`='$id'";
    echo $qury;
    if (mysqli_query($conn, $qury)) {
        echo "Update Success";
        header("location:showpricing.php?er=2");
    } else {
        echo "Update Failed";
        header("location:showpricing.php?er=3");
    }
} else {
    header("Location:showpricing.php");
}