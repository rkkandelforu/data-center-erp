<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include 'headerfiles.php';
    ?>
    <script>
        function readandpreview(fileobj, imageid) {
            var firstfile = fileobj.files[0];
            var reader = new FileReader();
            reader.onload = (function (f) {
                return function read(e) {
                    document.getElementById(imageid).src = e.target.result;
                    document.getElementById(imageid).style.display = "flex";
                }
            })(firstfile);
            reader.readAsDataURL(firstfile);
        }
    </script>
</head>
<body>
<?php
include_once 'userheader.php';
?>

<div class="about-heading">
    <h2>Two Minds <span> Technology</span></h2>
</div>
<!-- //about-heading -->
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <h3>Customer Support Form</h3>
            <div class="login-form">
                <form action="insertproblem.php" id="form1" method="post" enctype="multipart/form-data">
                    <div class="row justify-content-center offset-1">
                        <img src="" class="img-fluid" style="height: 200px;width: 200px;display: none" id="showimg"
                             alt="">
                    </div>
                    <div class="row form-group justify-content-center offset-1">
                        <label for="category" class="font-weight-bolder"><u>Category</u></label>
                        <select type="text" name="category" id="category" data-rule-required="true"
                                data-msg-required="Category selection is mandatory" class="form-control">
                            <option value="">Select category</option>
                            <option value="Technical Ticket">Technical Ticket</option>
                            <option value="Sales Ticket">Sales Ticket</option>
                        </select>
                    </div>
                    <div class="row form-group justify-content-center offset-1">
                        <label for="title" class="font-weight-bolder"><u>Title</u></label>
                        <input type="text" name="title" id="title" data-rule-required="true"
                               data-msg-required="Title is mandatory" placeholder="enter Title"
                               class="input-field">
                    </div>
                    <div class="row form-group justify-content-center offset-1">
                        <label for="symbol" class="font-weight-bolder"><u>Picture</u></label>
                        <input type="file" name="symbol" id="symbol" data-rule-extension="jpg|png|gif"
                               class="form-control"
                               onchange="readandpreview(this,'showimg')">
                    </div>
                    <div class="row form-group justify-content-center offset-1">
                        <label for="description" class="font-weight-bolder"><u>Description</u></label>
                        <textarea name="description" id="description" data-rule-required="true"
                                  data-msg-required="Description must be entered" class="input-field" cols="20" rows="5"
                                  placeholder="enter problem description "></textarea>
                    </div>

                    <div class="tp">
                        <input type="submit" name="submit" value="Post Problem">
                    </div>
                </form>
            </div>
            <div class="modal" id="fail">
                <div class="modal-dialog modal-lg modal-sm">
                    <div class="modal-content">
                        <div class="modal-header justify-content-center">
                            <div class="row text-center mt-4">
                                <h1>Message: </h1>
                            </div>
                        </div>
                        <div class="modal-body signin-form profile">
                           <h2>Failed To Post Problem</h2>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal" id="success">
                <div class="modal-dialog modal-lg modal-sm">
                    <div class="modal-content">
                        <div class="modal-header justify-content-center">
                            <div class="row text-center mt-4">
                                <h4>Message</h4>
                            </div>
                        </div>
                        <div class="modal-body signin-form profile">
                            <h2>Problem Posted Successfully</h2>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="modal" id="image">
                <div class="modal-dialog modal-lg modal-sm">
                    <div class="modal-content">
                        <div class="modal-header justify-content-center">
                            <div class="row text-center mt-4">
                                <h4>Message</h4>
                            </div>
                        </div>
                        <div class="modal-body signin-form profile">
                            <h2>Image must be less than 200 kb</h2>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div class="row form-group col-md-8 justify-content-center offset-2">
        <?php
        if (isset($_REQUEST['er'])) {
            $val = $_REQUEST['er'];
            if ($val == 0) {
                echo "<script>
                    function showmodal() {
                        $(\"#success\").modal(\"show\");

                    }
                    showmodal();
                </script>";
//                echo '<div class="alert alert-success">
//                        Problem Posted Successfully
//                        <span class="close" data-dismiss="alert">&times;</span>
//                            </div>';
            } elseif ($val == 1) {
                echo "<script>
                    function showmodal() {
                        $(\"#fail\").modal(\"show\");

                    }
                    showmodal();
                </script>";
            } elseif ($val == 2) {
                echo "<script>
                    function showmodal() {
                        $(\"#image\").modal(\"show\");

                    }
                    showmodal();
                </script>";
            }
        }
        ?>
    </div>
</div>

<?php
include_once 'footer.php';
?>
</body>
</html>
