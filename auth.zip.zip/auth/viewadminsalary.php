<?php include_once "connect.php"; ?>

    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <?php
        include 'headerfiles.php';
        ?>
    </head>
    <body>
    <div class="container-fluid">
        <?php
        include_once 'adminheader.php';
        ?>
        <div class="row text-center">
            <h2>View Your Salary Disbursement</h2>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>Sr no.</th>
                    <th>Date Of Disbursement</th>
                    <th>Admin Full Name with designation</th>
                    <th>Salary</th>
                    <th>Perks</th>
                    <th>Month</th>
                    <th>Year</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $qury = "select * from salary_disburse inner join admin on salary_disburse.adminid=admin.username where salary_disburse.adminid='$row[0]'";
                $k = 0;
                $result = mysqli_query($conn, $qury);
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_array($result)) {
                        $k++;
                        ?>
                        <tr>
                            <td><?php echo $k; ?></td>
                            <td><?php echo $row['dateofdisbursement']; ?></td>
                            <td class="text-capitalize"><?php echo $row['fullname'] . "    (" . $row['designation'] . ")"; ?></td>
                            <td>$ <?php echo $row['salary']; ?></td>
                            <td>$ <?php echo $row['perks']; ?></td>
                            <td><?php echo $row['month']; ?></td>
                            <td><?php echo $row['year']; ?> </td>
                        </tr>
                        <?php
                    }
                } else {
                    echo "No Data Found";
                }
                ?>
                </tbody>
            </table>
        </div>
        <?php
        include_once 'footer.php';
        ?>
    </div>
    </body>
    </html>
<?php
