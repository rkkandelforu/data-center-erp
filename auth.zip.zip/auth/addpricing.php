<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include 'headerfiles.php';
    ?>
</head>
<body>
<?php
include_once 'adminheader.php';
?>

<div class="about-heading">
    <h2>Two Minds <span> Technology</span></h2>
</div>
<!-- //about-heading -->
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <h3>Add Pricing Form</h3>
            <div class="login-form">
                <form action="insertpricing.php" id="form1" method="post" enctype="multipart/form-data">
                    <div class="row form-group justify-content-center">
                        <label for="category" class="font-weight-bolder"><u>Package</u></label>
                        <select name="package" id="package" data-rule-required="true"
                                data-msg-required="Package selection is mandatory" class="form-control">
                            <option value="">Select Package</option>
                            <?php
                            $sqls = "select * from package";
                            $results = mysqli_query($conn, $sqls);
                            while ($rows = mysqli_fetch_array($results)) {
                                ?>
                                <option value="<?php echo $rows["packageid"]; ?>"><?php echo $rows["packagename"]; ?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="row form-group justify-content-center">
                        <label for="amount" class="font-weight-bolder"><u>Package Amount</u></label>
                        <input type="text" name="amount" id="amount" data-rule-required="true" data-rule-number="true"
                               data-msg-required="Package amount is mandatory" placeholder="enter package amount"
                               class="input-field">
                    </div>
                    <div class="row form-group justify-content-center">
                        <label for="duration" class="font-weight-bolder"><u>Package Duration</u></label>
                        <input type="text" name="duration" id="duration" data-rule-required="true" data-rule-number="true"
                               data-msg-required="Package duration is mandatory" placeholder="enter package duration"
                               class="input-field">
                    </div>
                    <div class="row form-group justify-content-center">
                        <label for="offer" class="font-weight-bolder"><u>Package Offer (in %)</u></label>
                        <input type="text" name="offer" id="offer" data-rule-required="true" data-rule-number="true"
                               data-msg-required="Package offer is mandatory" placeholder="enter package offer"
                               class="input-field">
                    </div>
                    <div class="tp">
                        <input type="submit" name="submit" value="Add Pricing">
                    </div>
                </form>
            </div>

            <div class="row form-group col-md-8 justify-content-center offset-2">
                <?php
                if (isset($_REQUEST['er'])) {
                    $val = $_REQUEST['er'];
                    if ($val == 0) {
                        echo '<div class="alert alert-success">
                        Pricing Added Successfully
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                    } elseif ($val == 1) {
                        echo '<div class="alert alert-danger">
                        Try Again Later
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                    } elseif ($val == 3) {
                        echo '<div class="alert alert-warning">
                        Pricing already exists
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
                    }
                }
                ?>
            </div>

        </div>
    </div>
</div>

<?php
include_once 'footer.php';
?>
</body>
</html>
