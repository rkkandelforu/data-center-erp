<!DOCTYPE html>
<html lang="en">
<head>
<title>Hosting City a Hosting Category Flat Bootstrap responsive Website Template | Registration :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Hosting City Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<?php include_once "headerfiles.php";?>
</head>
<body>
	<?php include_once "navbar.php";?>
	<!-- about-heading -->
	<div class="about-heading">
		<h2>Registration <span>    <h2>Two Minds <span> Technology</span></h2>
</span></h2>
	</div>
	<!-- //about-heading -->
	<div class="registration">
		<div class="container">
			<div class="signin-form profile">
				<h3>Register</h3>
                <div class="text-danger"><?php if(isset($_GET['status'])){ if($_GET['status'] == 0){
                    echo "Password and Confirm Password not Match"; }elseif ($_GET['status'] == 11){
                    echo "Registration Done";
                    } elseif ($_GET['status'] == 00){
                    echo "Db Error";
                    } elseif ($_GET['status'] == 000){
                        echo "Email Already Exists";
                }
                } ?></div>
				
				<div class="login-form">
					<form action="registration_action.php" method="post" id="form1">
                        <input type="text" name="cid" placeholder="Cust id" data-rule-required="true" data-rule-number="true">
						<input type="email" name="email" placeholder="E-mail" data-rule-required="true" data-rule-email="true">
						<input type="password" name="password" id="password" placeholder="Password" data-rule-required="true">
						<input type="password" name="conpassword" placeholder="Confirm Password" data-rule-required="true" data-rule-equalto="#password">
                        <input type="text" name="mobile" placeholder="Mobile Number" minlength="10" maxlength="12" data-rule-required="true" data-rule-number="true">
                        Male
                        <input type="radio" name="gender" checked value="male"  required>
                        Female
                        <input type="radio" name="gender" value="female"  required>

                        <input type="submit" name="submit" value="REGISTER">
					</form>
				</div>
				<p><a href="#"> By clicking register, I agree to your terms</a></p>
			</div>
		</div>
	</div>
<?php include "footer.php"; ?>
</body>	
</html>