<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php
    include 'headerfiles.php';
    ?>
    <title>User Login</title>
</head>
<body>
<?php
include_once 'navbar.php';
?>
<div class="registration">
    <div class="container">
        <div class="signin-form profile">
            <h3>Login</h3>
            <form action="userchecklogin.php" id="form1" method="post">
                <input type="email" placeholder="enter email" name="email" id="email" data-rule-required="true">
                <input type="password" placeholder="enter password" name="password" data-rule-required="true"
                       id="password">
                <div class="tp">
                    <input type="submit" name="submit" value="LOGIN NOW">
                </div>
            </form>
        </div>
        <?php
        if (isset($_REQUEST['er'])) {
            $val = $_REQUEST['er'];
            if ($val == 1) {
                echo '<div class="alert alert-danger">
                        Invalid email or password
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
            }
        } ?>
    </div>
</div>


</div>
<?php
include_once 'footer.php';
?>

</body>
</html>
