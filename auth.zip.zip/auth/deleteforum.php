<?php
include 'adminheader.php';
include_once 'connect.php';

$id = $_REQUEST["id"];
$qury = "DELETE FROM `discussion_forum` WHERE id='$id'";
if (mysqli_query($conn,$qury))
{
    header("location:view-discussion.php");
}
else{
    header("location:discussion.php");
}
