<?php include_once "connect.php"; ?>

    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <?php
        include 'headerfiles.php';
        ?>
    </head>
    <body>
    <div class="container-fluid">
        <?php
        include_once 'adminheader.php';
        ?>
        <div class="row text-center">
            <h2>View Salary Disbursement</h2>
        </div>
        <div class="row text-center" style="margin-bottom: 50px">
            <div class="col-sm-2"></div>
            <div class="col-sm-8">
                <label for="category" class="">Select Admin</label>
                <select name="admin" class="form-control" id="admin" onchange="show_salarydis(this.value)">
                    <option value="">Select Admin</option>
                    <?php
                    $qury = "select * from admin";
                    $res = mysqli_query($conn, $qury);
                    while ($category = mysqli_fetch_assoc($res)) {
                        ?>
                        <option value="<?php echo $category["username"]; ?>"><?php echo $category["fullname"]; ?></option>
                        <?php
                    }
                    ?>
                </select>
            </div>
            <div class="col-sm-2"></div>

        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>Sr no.</th>
                    <th>Date Of Disbursement</th>
                    <th>Admin Full Name with designation</th>
                    <th>Salary</th>
                    <th>Perks</th>
                    <th>Month</th>
                    <th>Year</th>
                </tr>
                </thead>
                <tbody id="salarydis">
                </tbody>
            </table>
        </div>
        <?php
        include_once 'footer.php';
        ?>
    </div>


    <script>
        function show_salarydis(str) {
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    // alert(this.responseText);
                    document.getElementById("salarydis").innerHTML = this.responseText;
                }
            };
            if (str == '') {
                xmlhttp.open("GET", "getsalarydis.php", true);
            } else {
                xmlhttp.open("GET", "getsalarydis.php?q=" + str, true);
            }
            xmlhttp.send();
        }

        $(document).ready(function () {
            show_salarydis('');
        })
    </script>

    </body>
    </html>
<?php
