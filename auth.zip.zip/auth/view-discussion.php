<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include 'headerfiles.php';
    ?>
</head>
<body>
<?php
include_once 'adminheader.php';
?>
<div class="about-heading">
    <h2>Add Discussion @<span>    <h2>Two Minds <span> Technology</span></h2>
</span></h2>
</div>
<div class="container">

    <h3>Vew Discussion</h3>

    <table class="table table-bordered">
        <thead>
        <tr>
            <th>Srno</th>
            <th>Title</th>
            <th>Description</th>
            <th>Date of Post</th>
            <th>control</th>
        </tr>
        </thead>
        <tbody>
        <?php
        include_once "connect.php";
        $sql = "SELECT * FROM `discussion_forum`";
        $data = mysqli_query($conn, $sql);
        $srno = 1;
        while ($row = mysqli_fetch_array($data)) {
            ?>
            <tr>
                <td><?php echo $srno; ?></td>
                <td><?php echo $row[1]; ?></td>
                <td><?php echo $row[2]; ?></td>
                <td><a onclick="return confirm('are you sure to delete ?')"
                       href="deleteforum.php?id=<?php echo $row[0]; ?>">Remove</a><?php ?></td>
            </tr>
            <?php
            $srno++;
        }
        ?>
        </tbody>
    </table>
</div>
<?php
include_once 'footer.php';
?>
</body>
</html>
