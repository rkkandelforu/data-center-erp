<?php
include_once 'connect.php';
if (isset($_GET['q'])) {
    $pack = $_GET['q'];
    $qury = "select * from salary_disburse inner join admin on salary_disburse.adminid=admin.username where salary_disburse.adminid='$pack'";
} else {
    $qury = "select * from salary_disburse inner join admin on salary_disburse.adminid=admin.username";
}
$k = 0;
$result = mysqli_query($conn, $qury);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        $k++;
        ?>
        <tr>
            <td><?php echo $k; ?></td>
            <td><?php echo $row['dateofdisbursement']; ?></td>
            <td class="text-capitalize"><?php echo $row['fullname']."    (".$row['designation'].")"; ?></td>
            <td>$ <?php echo $row['salary']; ?></td>
            <td>$ <?php echo $row['perks']; ?></td>
            <td><?php echo $row['month']; ?></td>
            <td><?php echo $row['year']; ?> </td>
        </tr>
        <?php
    }
} else {
    echo "No Data Found";
}
?>