<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    ob_start();
    include_once 'headerfiles.php';
    ?>
</head>
<body>
<?php
include_once 'userheader.php';
if (isset($_POST['pricing'])) {
    $pricing = $_POST['pricing'];
    $sql = "select * from pricing inner join package on package.packageid=pricing.packageid where pid='$pricing'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result);

    if (!empty($row['offer']) && $row['offer'] > 0) {
        $discountedPrice = $row['amount'] - ($row['amount'] * $row['offer'] / 100);
//        echo $discountedPrice;
    } else {
        $discountedPrice = $row['amount'];
//        echo $row['amount'];
    }

    date_default_timezone_set("Asia/Kolkata");
    $currentDateTime = date('Y-m-d');
    $dm = $row['duration'];
    $ed = date('Y/m/d', strtotime('+' . $dm . ' months'));
    $billdata = array("pricingid" => $pricing, "total" => $discountedPrice, "custid" => $user_row[0], "doe" => $ed);
    $_SESSION['billdata'] = $billdata;
} else {
    header("Location:index.php");
}
?>
<div class="registration">
    <div class="container">
        <form action="http://www.paypal.com/cgi-bin/webscr" id="form1" method="post">
            <input type="hidden" name="business" value="vmmeducation@gmail.com"/>
            <input type="hidden" name="upload" value="1"/>
            <input type="hidden" name="cmd" value="_cart"/>
            <!--            <div class="row">-->
            <!--                <div class="col-sm-6 signin-form profile">-->
            <!--                    <div class="w3-banner-bottom-heading">-->
            <!--                        <h3>Billing<span> form </span></h3>-->
            <!--                    </div>-->
            <!--                    <div class="row">-->
            <!--                        <label for="">City</label>-->
            <!--                        <input type="text" name="city" class="" id="city" data-rule-required="true">-->
            <!--                    </div>-->
            <!--                    <div class="row">-->
            <!--                        <label for="">Zipcode</label>-->
            <!--                        <input type="text" name="zipcode" class="" id="zipcode" data-rule-required="true"-->
            <!--                               data-rule-number="true">-->
            <!--                    </div>-->
            <!--                    <div class="row">-->
            <!--                        <label for="">Address</label>-->
            <!--                        <textarea type="text" name="address" class="" rows="5" id="address"-->
            <!--                                  data-rule-required="true"></textarea>-->
            <!--                    </div>-->
            <!--                </div>-->
            <div class="signin-form profile">
                <div class="w3-banner-bottom-heading">
                    <h3>Billing<span> Detail </span></h3>
                </div>
                <div class="row">

                    <div class="row">
                        <label for="">Total</label>
                        <input readonly type="text" value="<?php echo $discountedPrice; ?>" name="total" class=""
                               id="total">
                    </div>
                    <div class="row">
                        <input type="hidden" name="pricing" class="" readonly id="pricing"
                               value="<?php echo $pricing; ?>" data-rule-required="true" data-rule-number="true">
                        <label for="">User Email</label>
                        <input type="text" name="" class="" readonly id=""
                               value="<?php echo $user_row[2]; ?>">
                        <input
                                type="hidden" name="custid" class="" readonly id="custid"
                                value="<?php echo $user_row[0]; ?>" data-rule-required="true"
                                data-rule-number="true">

                    </div>
                    <div class="row">
                        <label for="">Date of Expiry</label>
                        <input type="text" name="doe" readonly class="" id="doe" value="<?php echo $ed; ?>">
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <img style="height: 100px;width: 150px" src="<?php echo $row["photo"]; ?>" alt="">
                        </div>
                        <div class="col-sm-6">
                            <h2><?php echo $row['category']; ?></h2>
                            <h2><?php echo $row['packagename']; ?></h2>
                            <h5>Duration: <?php echo $row["duration"]; ?> months&nbsp;@ &#8377; <?php
                                if (!empty($row['offer']) && $row['offer'] > 0) {
                                    $discountedPrice = $row['amount'] - ($row['amount'] * $row['offer'] / 100);
                                    echo $discountedPrice;
                                } else {
                                    echo $row['amount'];
                                }
                                ?></h5>
                            <p>Save <?php echo $row["offer"]; ?> %</p></div>
                    </div>
                </div>
            </div>
            <!--            </div>-->
            <div class="row text-center">
                <input type="hidden" name="item_name_1" value="Shopping Bill Payment"/>
                <input name="amount_1" type="hidden" value="<?php echo $discountedPrice ?>" id="sp1"/>
                <input type="submit" class="btn btn-primary" value="Pay">
                <input type="hidden" name="return" value="http://localhost/auth/insertbill.php"/>
                <input type="hidden" name="cancel_return" value="http://localhost/auth/insertbill.php"/>
                <input type="hidden" name="notify_url" value="http://localhost/auth/insertbill.php"/>
            </div>
        </form>
    </div>
</div>
<?php
include_once 'footer.php';
?>
</body>
</html>
<?php
