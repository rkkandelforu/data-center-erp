<?php
include 'adminheader.php';
include_once 'connect.php';

$packagename = $_POST["packagename"];
$description = $_POST["description"];
$category = $_POST["category"];
$photo = $_FILES["symbol"]["tmp_name"];
$path = '';
$error = "";
if ($photo != "") {
    $filename = $_FILES["symbol"]["name"];
    $ext = pathinfo(strtolower($filename), PATHINFO_EXTENSION);
    if (round($_FILES["symbol"]["size"] / 1024) > 200) {
        $error = "Image size must be less than 100 kb";
        header("location:addpackage.php?er=2");
    } else {
        $path = "photos/$filename";
        move_uploaded_file($photo, $path);
    }
}

if ($error == "") {
    $s = "select * from package where packagename='$packagename' and category='$category'";
    $result = mysqli_query($conn, $s);
    if (mysqli_num_rows($result) > 0) {
        echo 3;
        header("Location:addpackage.php?er=3");
    } else {
        $qury = "INSERT INTO `package`(`packageid`,`packagename`, `description`, `photo`,`category`) VALUES (null ,'$packagename','$description','$path','$category')";
        echo $qury;
        if (mysqli_query($conn, $qury)) {
            echo 0;
            header("location:addpackage.php?er=0");
        } else {
            echo 1;
            header("location:addpackage.php?er=1");
        }
    }
} else {
    echo $error;
    header("location:addpackage.php?er=4");
}