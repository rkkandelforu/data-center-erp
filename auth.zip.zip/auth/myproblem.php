<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Auth</title>
    <?php
    ob_start();
    include_once 'headerfiles.php';
    ?>
</head>
<body>
<?php
include_once 'userheader.php';
?>
<div class="main-sec"></div>

<div class="container">
    <div class="row text-center">
        <h1>My Questions</h1>
    </div>

    <table class="table bg-info table-bordered table-condensed">
        <thead>
        <tr>
            <th>Sr no.</th>
            <th>Photo</th>
            <th>Title</th>
            <th>Description</th>
            <th>Category</th>
            <th>Reply</th>
            <th>Full Conversation</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $qury = "select * from customersupport inner join users on users.id=customersupport.postedby where postedby='$user_row[0]'";
        $k = 0;
        $result = mysqli_query($conn, $qury);
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                $k++;
                ?>
                <tr>
                    <td><?php echo $k ?></td>
                    <td><img style="height: 150px;width: 250px" src="<?php echo $row["photo"]; ?>" alt=""></td>
                    <td><?php echo $row['title']; ?></td>
                    <td><?php echo $row['description']; ?></td>
                    <td><?php echo $row['category']; ?></td>
                    <td><a onclick="showmodal('<?php echo $row['csid']; ?>')"><i class="fa fa-reply"></i></a></td>
                    <td>
                        <button onclick="showstory('<?php echo $row['csid']; ?>')"><i class='fa fa-info-circle'></i>
                        </button>
                    </td>
                </tr>
                <?php
            }
        } else {
            ?>
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-danger">No Data Found <span class="close"
                                                                        data-dismiss="alert">&times;</span></div>
                </div>
            </div>
            <?php
        }
        ?>
        </tbody>
    </table>
    <div class="modal" id="modaldetail">
        <div class="modal-dialog modal-lg modal-sm">
            <div class="modal-content">
                <div class="modal-header justify-content-center">
                    <div class="row text-center mt-4">
                        <h1>Add Reply: </h1>
                    </div>
                </div>
                <div class="modal-body signin-form profile">
                    <form action="addreplyuser.php" method="post" id="form1">
                        <div class="row form-group justify-content-center offset-1">
                            <label for="description" class="font-weight-bolder"><u>Reply</u></label>
                            <textarea name="description" id="description" data-rule-required="true"
                                      data-msg-required="Description must be entered" class="input-field" cols="20"
                                      rows="5"
                                      placeholder="enter reply "></textarea>
                        </div>
                        <div class="row offset-3 col-sm-6 mt-4">
                            <input type="hidden" name="csid" value="" id="csid">
                            <input type="submit" name="" id="" value="Add"
                                   class="btn btn-success text-center">
                        </div>
                    </form>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>

                </div>
            </div>
        </div>


    </div>

    <div class="modal" id="story">
        <div class="modal-dialog modal-sm modal-lg">
            <div class="modal-content">
                <div class="modal-header justify-content-center">
                    <div class="row text-center mt-4">
                        <h3>View All Chat.</h3>
                    </div>
                </div>
                <div class="modal-body justify-content-center">
                    <div class="table-responsive" id="">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>Sr no.</th>
                                <th>Reply</th>
                                <th>Reply By</th>
                                <th>Date Time</th>
                            </tr>
                            </thead>
                            <tbody id="detail"></tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="row form-group col-md-8 justify-content-center offset-2">
        <?php
        if (isset($_REQUEST['er'])) {
            $val = $_REQUEST['er'];
            if ($val == 0) {
                echo '<div class="alert alert-success">
                        Reply Added Successfully
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
            } elseif ($val == 1) {
                echo '<div class="alert alert-danger">
                        Try Again Later
                        <span class="close" data-dismiss="alert">&times;</span>
                            </div>';
            }
        }
        ?>
    </div>
</div>
<?php
include_once 'footer.php';
?>
<script>
    function showmodal(csid) {
        document.getElementById("csid").value = csid;
        $("#modaldetail").modal("show");
    }

    function showstory(csid) {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                $("#story").modal("show");
                document.getElementById('detail').innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "viewstory.php?q=" + csid, true);
        xhttp.send();

    }
</script>
</body>
</html>
<?php
