<?php include_once "connect.php"; ?>

    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <?php
        include 'headerfiles.php';
        ?>
    </head>
    <body>
    <?php
    include_once 'adminheader.php';
    ?>
    <br>


    <div class="container">
        <div class="row justify-content-around">
            <h2>View Admins</h2>
        </div>
        <table class="table table-striped">
            <thead>
            <tr>
                <th>Sr no.</th>
                <th>User Name</th>
                <th>Email_id</th>
                <th>Mobile</th>
                <th>Fullname</th>
                <th>Father Name</th>
                <th>Address</th>
                <th>Designation</th>
                <th>Type</th>
                <th>Monthly Salary</th>
                <th>Update</th>
                <th>Delete</th>

            </tr>
            </thead>
            <tbody>
            <?php
            $k=0;
            $qury = "select * from admin";
            $result = mysqli_query($conn, $qury);
            while ($admin = mysqli_fetch_array($result)) {
                $k++;
                ?>
                <tr>
                    <td><?php echo $k;?></td>
                    <td><?php echo $admin[0]; ?></td>
                    <td><?php echo $admin[1]; ?></td>
                    <td><?php echo $admin[3]; ?></td>
                    <td><?php echo $admin[4]; ?></td>
                    <td><?php echo $admin['father']; ?></td>
                    <td><?php echo $admin['address']; ?></td>
                    <td><?php echo $admin['designation']; ?></td>
                    <td><?php echo $admin['type']; ?></td>
                    <td>$ <?php echo $admin['monthlysalary']; ?></td>
                    <td><a href="editadmin.php?username=<?php echo $admin[0]; ?>"><i class="fa fa-edit"></i></a></td>

                    <?php
                    if ($admin[0] == $username) {

                    } else {
                        ?>
                        <td><a onclick="return confirm('Are you Sure you want to Delete?')"
                               href="deleteadmin.php?username=<?php echo $admin[0]; ?>"><i class="fa fa-trash"></i></a>
                        </td>

                        <?php
                    }
                    ?>
                </tr>
                <?php

            }
            ?>
            </tbody>
        </table>
        <?php
        if (isset($_GET['er'])) {
            $msg = $_GET["er"];
            if ($msg == 0) {
                echo "<script>alert('Admin Deleted Successfully')</script>";
            } elseif ($msg == 1) {
                echo "<script>alert('Failed to delete Admin')</script>";
            } elseif ($msg == 3) {
                echo "<script>alert('Failed to Update Admin')</script>";
            } elseif ($msg == 2) {
                echo "<script>alert('Admin Updated Successfully')</script>";
            }
        }
        ?>
    </div>
    <?php
    include_once 'footer.php';
    ?>
    </body>
    </html>
<?php
